package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Skills;
import com.it.helpdesk.server.service.SkillsService;
import com.it.helpdesk.server.utils.SkillsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class SkillsControllerTest {

    @Mock
    private SkillsService skillsService;

    @InjectMocks
    private SkillsController skillsController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSaveOneSkills() {
        Skills skill1 = new Skills();
        skill1.setId(1L);
        skill1.setName("Java");

        Skills skill2 = new Skills();
        skill2.setId(2L);
        skill2.setName("Spring Boot");

        List<Skills> skillsToSave = Arrays.asList(skill1, skill2);
        when(skillsService.saveSkills(skillsToSave)).thenReturn(skillsToSave);
        List<Skills> savedSkills = skillsController.saveOneSkills(skillsToSave);

        assertEquals(skillsToSave, savedSkills);
        verify(skillsService, times(1)).saveSkills(skillsToSave);
    }

    @Test
    void testSearchSkills() {
        Skills skill1 = new Skills();
        skill1.setId(1L);
        skill1.setName("Java");

        Skills skill2 = new Skills();
        skill2.setId(2L);
        skill2.setName("Spring Boot");

        List<Skills> skillsList = Arrays.asList(skill1, skill2);
        List<String> skillNames = skillsList.stream().map(skill -> skill.getName()).collect(Collectors.toList());
        when(skillsService.searchSkills()).thenReturn(createSkillsResponse(skillNames));
        SkillsResponse response = skillsController.searchSkills();

        assertEquals(skillNames, response.getSkills());
        verify(skillsService, times(1)).searchSkills();
    }

    private SkillsResponse createSkillsResponse(List<String> skills) {
        SkillsResponse response = new SkillsResponse();
        response.setSkills(skills);
        return response;
    }
}
