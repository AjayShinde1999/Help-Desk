package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.repository.ConversationRepository;
import com.it.helpdesk.server.repository.TicketRepository;
import com.it.helpdesk.server.service.impl.ConversationServiceImpl;
import com.it.helpdesk.server.utils.AppConstant;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.oauth2.jwt.Jwt;

import java.nio.file.AccessDeniedException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ConversationServiceTest {

    @Mock
    private ConversationRepository conversationRepository;

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private Jwt jwt;

    @InjectMocks
    private ConversationServiceImpl conversationService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveConversation_UserRole_UserIsReader() throws AccessDeniedException {
        long ticketId = 123L;
        Ticket ticket = new Ticket();
        ticket.setTicketNo("3kt123");
        ticket.setTicketOwnerRole("user");

        when(ticketRepository.findById(ticketId)).thenReturn(Optional.of(ticket));
        when(jwt.getClaim(AppConstant.ROLE)).thenReturn(Arrays.asList("user"));
        when(jwt.getClaim(AppConstant.USERNAME)).thenReturn("test");
        when(jwt.getClaim(AppConstant.EMAIL)).thenReturn("test@3kt.com");

        Conversation inputConversation = new Conversation();
        inputConversation.setMessage("passing tet cases");
        inputConversation.setTimestamp(String.valueOf(new Date()));

        Conversation expectedConversation = new Conversation();
        expectedConversation.setTicket(ticket);
        expectedConversation.setName("test");
        expectedConversation.setEmail("test@3kt.com");
        expectedConversation.setTicketNo("3kt123");
        expectedConversation.setMessage("passing test cases");
        expectedConversation.setTimestamp(inputConversation.getTimestamp());
        expectedConversation.setReadByUser(true);
        expectedConversation.setReadByAdmin(false);

        when(conversationRepository.save(any(Conversation.class))).thenReturn(expectedConversation);

        Conversation result = conversationService.saveConversation(jwt, inputConversation, ticketId);

        assertNotNull(result);
        assertTrue(result.isReadByUser());
        assertFalse(result.isReadByAdmin());
        verify(conversationRepository).save(any(Conversation.class));
    }

    @Test
    public void testFetchUsersMessagesForAdmin_AdminRoleWithTicketWrite() {
        long ticketId = 1L;
        List<String> roles = Arrays.asList(AppConstant.TICKET_WRITE);

        Conversation adminConversation = new Conversation();
        adminConversation.setTicketOwnerRole("admin");
        adminConversation.setReadByUser(false);
        List<Conversation> conversations = Arrays.asList(adminConversation);
        when(conversationRepository.findByTicketId(ticketId)).thenReturn(conversations);

        List<Conversation> updatedConversations = conversationService.fetchUsersMessagesForAdmin(ticketId, roles);

        assertTrue("The conversation should be marked as read by user", updatedConversations.get(0).isReadByUser());
        assertFalse("The conversation should not be marked as read by admin", updatedConversations.get(0).isReadByAdmin());
        verify(conversationRepository).saveAll(conversations);

    }

    @Test
    public void testFetchAdminMessagesForUser() {
        long ticketId = 1L;
        Conversation conversation1 = new Conversation();
        conversation1.setReadByUser(false);

        Conversation conversation2 = new Conversation();
        conversation2.setReadByUser(false);

        List<Conversation> conversations = Arrays.asList(conversation1, conversation2);
        when(conversationRepository.findByTicketId(ticketId)).thenReturn(conversations);

        List<Conversation> updatedConversations = conversationService.fetchAdminMessagesForUser(ticketId);

        assertNotNull(updatedConversations);
        assertTrue(updatedConversations.stream().allMatch(Conversation::isReadByUser));
        assertEquals(2, updatedConversations.size());
        verify(conversationRepository).findByTicketId(ticketId);
        verify(conversationRepository).saveAll(conversations);
    }
}
