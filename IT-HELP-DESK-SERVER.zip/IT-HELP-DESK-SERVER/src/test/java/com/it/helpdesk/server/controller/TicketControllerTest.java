package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.DropdownValues;
import com.it.helpdesk.server.payload.TicketDto;
import com.it.helpdesk.server.security.TicketAuthentication;
import com.it.helpdesk.server.service.ExcelService;
import com.it.helpdesk.server.utils.ExcelResponse;
import com.it.helpdesk.server.utils.RefreshResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.jwt.Jwt;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketControllerTest {

    @Mock
    private TicketAuthentication ticketAuthentication;

    @Mock
    private ExcelService excelService;

    @InjectMocks
    private TicketController ticketController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testCreateTicketWithImage() throws IOException, MessagingException {
        Jwt jwt = mockJwt();
        TicketDto ticketDto = mock(TicketDto.class);
        Ticket ticket = mock(Ticket.class);
        when(ticketAuthentication.authenticateUserForTicketWithImage(jwt, ticketDto)).thenReturn(ticket);
        Ticket createdTicket = ticketController.createTicketWithImage(jwt, ticketDto);
        assertEquals(ticket, createdTicket);
    }

    private Jwt mockJwt() {
        Jwt jwt = mock(Jwt.class);
        lenient().when(jwt.getClaim("name")).thenReturn("manojkumar k s");
        lenient().when(jwt.getClaim("preferred_username")).thenReturn("manoj.ks@3ktechnologies");
        lenient().when(jwt.getClaim("aud")).thenReturn(Collections.singletonList("mockedClientId"));
        lenient().when(jwt.getClaim("roles")).thenReturn(Collections.singletonList("ticket.write"));
        return jwt;
    }

    @Test
    void testCreateTicketWithoutImage() throws IOException, MessagingException {
        Jwt jwt = mockJwt();
        Ticket ticket = mock(Ticket.class);
        when(ticketAuthentication.authenticateUserForTicketWithoutImage(jwt, ticket)).thenReturn(ticket);
        Ticket createdTicket = ticketController.createTicketWithoutImage(jwt, ticket);
        assertEquals(ticket, createdTicket);
    }

    @Test
    void testFetchAllTickets() {
        Jwt jwt = mockJwt();
        List<Ticket> tickets = Arrays.asList(mock(Ticket.class), mock(Ticket.class)); // Mock list of tickets
        when(ticketAuthentication.authenticateUserForFetchAllTickets(jwt)).thenReturn(tickets);
        List<Ticket> fetchedTickets = ticketController.fetchAllTickets(jwt);
        assertEquals(tickets.size(), fetchedTickets.size());
        for (int i = 0; i < tickets.size(); i++) {
            assertEquals(tickets.get(i), fetchedTickets.get(i));
        }
    }

    @Test
    void testUpdateTicket() throws IOException, MessagingException {
        Jwt jwt = mockJwt();
        long ticketId = 123;
        Ticket ticket = mock(Ticket.class);
        when(ticketAuthentication.authenticateUserForUpdateTicket(jwt, ticket, ticketId)).thenReturn(ticket);
        Ticket updatedTicket = ticketController.updateTicket(jwt, ticket, ticketId);
        assertEquals(ticket, updatedTicket);
    }

    @Test
    void testFetchDropdownValues() {
        Jwt jwt = mockJwt();
        DropdownValues dropdownValues = mock(DropdownValues.class);
        when(ticketAuthentication.authenticateUserForFetchDropdownValues(jwt)).thenReturn(dropdownValues);
        ResponseEntity<DropdownValues> responseEntity = ticketController.fetchDropdownValues(jwt);
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(dropdownValues, responseEntity.getBody());
    }

    @Test
    void testRefreshToken() {
        RefreshResponse response = ticketController.refreshToken();
        assertEquals("OK", response.getStatus());
    }

    @Test
    void testDownloadArchive() throws IOException {
        Jwt jwt = mockJwt();
        ExcelResponse excelResponse = mock(ExcelResponse.class);
        when(excelService.exportTicketsToExcel(jwt)).thenReturn(excelResponse);
        ExcelResponse response = ticketController.downloadArchive(jwt);
        assertEquals(excelResponse, response);
    }
}


