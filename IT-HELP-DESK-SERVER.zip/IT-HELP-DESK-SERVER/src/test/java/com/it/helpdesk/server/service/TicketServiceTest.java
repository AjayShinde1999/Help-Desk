package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.repository.ConversationRepository;
import com.it.helpdesk.server.repository.TicketRepository;
import com.it.helpdesk.server.service.impl.TicketServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.mail.MessagingException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
 class TicketServiceTest {

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private EmailService emailService;

    @Mock
    private ConversationRepository conversationRepository;

    @InjectMocks
    private TicketServiceImpl ticketService;

    @Test
     void testSaveOneTicketWithoutImage_ValidDate() throws MessagingException {

        String username = "user1";
        String email = "user1@example.com";
        Ticket ticket = new Ticket();
        ticket.setDate(LocalDate.now().toString());
        List<String> roles = new ArrayList<>();
        roles.add("ticket.write");
        Ticket savedTicket = new Ticket();
        savedTicket.setId(1L);

        when(ticketRepository.save(any(Ticket.class))).thenReturn(savedTicket);
        when(ticketRepository.findById(anyLong())).thenReturn(Optional.of(savedTicket));
        doNothing().when(emailService).createTicketEmail(any(Ticket.class));

        Ticket result = ticketService.saveOneTicketWithoutImage(username, email, ticket, roles);

        assertNotNull(result);
        assertEquals(savedTicket, result);
        verify(ticketRepository, times(2)).save(any(Ticket.class));
        verify(ticketRepository, times(1)).findById(anyLong());
        verify(emailService, times(1)).createTicketEmail(any(Ticket.class));
    }

    @Test
     void testFetchAllTickets() {
        List<Ticket> mockTickets = new ArrayList<>();
        Ticket openTicket = new Ticket();
        openTicket.setId(1L);
        openTicket.setStatus("open");

        Ticket progressTicket = new Ticket();
        progressTicket.setId(2L);
        progressTicket.setStatus("progress");

        Ticket closedTicket = new Ticket();
        closedTicket.setId(3L);
        closedTicket.setStatus("closed");

        mockTickets.add(openTicket);
        mockTickets.add(progressTicket);
        mockTickets.add(closedTicket);

        when(ticketRepository.findAll()).thenReturn(mockTickets);
        List<Conversation> mockConversations = new ArrayList<>();

        Conversation conversation1 = new Conversation();
        conversation1.setReadByAdmin(false);
        Conversation conversation2 = new Conversation();
        conversation2.setReadByAdmin(false);
        Conversation conversation3 = new Conversation();
        conversation3.setReadByAdmin(false);

        mockConversations.add(conversation1);
        mockConversations.add(conversation2);
        mockConversations.add(conversation3);

        lenient().when(conversationRepository.findByTicketIdAndReadByAdminIsFalse(anyLong())).thenReturn(mockConversations);
        List<Ticket> result = ticketService.fetchAllTickets();
        assertEquals(2, result.size()); // Expecting only open and progress tickets
        verify(ticketRepository, times(1)).findAll();
        verify(conversationRepository, times(2)).findByTicketIdAndReadByAdminIsFalse(anyLong());
    }

    @Test
     void testFetchTicketByHrIssue() {
        // Mock ticket data
        List<Ticket> tickets = new ArrayList<>();
        Ticket ticket1 = new Ticket();
        ticket1.setId(1L);
        ticket1.setTicketNo("TKT001");
        ticket1.setUsername("User1");
        ticket1.setEmail("hr@example.com");
        ticket1.setSubject("HR Issue");
        ticket1.setDate("2024-04-19");
        ticket1.setPriority("High");
        ticket1.setCategory("hr related issue");
        ticket1.setStatus("open");
        ticket1.setDescription("HR issue description");
        ticket1.setImageUrl("http://example.com/image1.jpg");
        ticket1.setComments("Additional comments");
        ticket1.setTicketCloseDate(null);
        ticket1.setModifiedBy(null);
        ticket1.setUnreadMsgCount(0);
        ticket1.setTicketOwnerRole("hr");
        tickets.add(ticket1);

        Ticket ticket2 = new Ticket();
        ticket2.setId(2L);
        ticket2.setTicketNo("TKT002");
        ticket2.setUsername("User2");
        ticket2.setEmail("user@example.com");
        ticket2.setSubject("Technical Issue");
        ticket2.setDate("2024-04-20");
        ticket2.setPriority("Medium");
        ticket2.setCategory("other issue");
        ticket2.setStatus("open");
        ticket2.setDescription("Technical issue description");
        ticket2.setImageUrl(null);
        ticket2.setComments(null);
        ticket2.setTicketCloseDate(null);
        ticket2.setModifiedBy(null);
        ticket2.setUnreadMsgCount(0);
        ticket2.setTicketOwnerRole("user");
        tickets.add(ticket2);

        Ticket ticket3 = new Ticket();
        ticket3.setId(3L);
        ticket3.setTicketNo("TKT003");
        ticket3.setUsername("User3");
        ticket3.setEmail("hr@example.com");
        ticket3.setSubject("HR Issue Resolved");
        ticket3.setDate("2024-04-21");
        ticket3.setPriority("Low");
        ticket3.setCategory("hr related issue");
        ticket3.setStatus("resolved");
        ticket3.setDescription("Resolved HR issue description");
        ticket3.setImageUrl(null);
        ticket3.setComments(null);
        ticket3.setTicketCloseDate("2024-04-22");
        ticket3.setModifiedBy("Admin");
        ticket3.setUnreadMsgCount(0);
        ticket3.setTicketOwnerRole("hr");
        tickets.add(ticket3);

        List<Conversation> conversations = new ArrayList<>();
        Conversation conversation1 = new Conversation();
        conversation1.setId(1L);
        conversation1.setMessage("Test message 1");
        conversation1.setReadByUser(false);
        conversations.add(conversation1);

        Conversation conversation2 = new Conversation();
        conversation2.setId(2L);
        conversation2.setMessage("Test message 2");
        conversation2.setReadByUser(false);
        conversations.add(conversation2);

        lenient().when(ticketRepository.findAll()).thenReturn(tickets);
        lenient().when(conversationRepository.findByTicketIdAndReadByUserIsFalse(anyLong())).thenReturn(conversations);
        lenient().when(conversationRepository.findByTicketIdAndReadByAdminIsFalse(anyLong())).thenReturn(conversations);

        List<Ticket> result = ticketService.fetchTicketByHrIssue("hr@example.com");

        assertEquals(2, result.size());
        assertEquals(2, result.get(0).getUnreadMsgCount());
        assertEquals(2, result.get(1).getUnreadMsgCount());
        verify(ticketRepository, times(1)).findAll();
    }

    @Test
     void testFetchTicketsByCategoryOtherThanHR() {
        Ticket ticket1 = new Ticket();
        ticket1.setId(1L);
        ticket1.setEmail("user1@example.com");
        ticket1.setCategory("issue1");
        ticket1.setStatus("open");
        ticket1.setTicketOwnerRole("admin");

        Ticket ticket2 = new Ticket();
        ticket2.setId(2L);
        ticket2.setEmail("user2@example.com");
        ticket2.setCategory("hr related issue");
        ticket2.setStatus("open");
        ticket2.setTicketOwnerRole("user");

        Ticket ticket3 = new Ticket();
        ticket3.setId(3L);
        ticket3.setEmail("user1@example.com");
        ticket3.setCategory("issue2");
        ticket3.setStatus("resolved");
        ticket3.setTicketOwnerRole("admin");

        List<Ticket> tickets = new ArrayList<>();
        tickets.add(ticket1);
        tickets.add(ticket2);
        tickets.add(ticket3);

        Conversation conversation1 = new Conversation();
        conversation1.setReadByUser(false);
        Conversation conversation2 = new Conversation();
        conversation2.setReadByUser(false);

        List<Conversation> conversations = new ArrayList<>();
        conversations.add(conversation1);
        conversations.add(conversation2);

        lenient().when(ticketRepository.findAll()).thenReturn(tickets);
        lenient().when(conversationRepository.findByTicketIdAndReadByUserIsFalse(anyLong())).thenReturn(conversations);
        lenient().when(conversationRepository.findByTicketIdAndReadByAdminIsFalse(anyLong())).thenReturn(conversations);
        List<Ticket> result = ticketService.fetchTicketsByCategoryOtherThanHR("user1@example.com");

        assertEquals(2, result.size());
        assertEquals(2, result.get(0).getUnreadMsgCount());
    }

    @Test
     void testFetchTicketByEmail() {

        String email = "user1@example.com";
        Ticket ticket1 = new Ticket();
        ticket1.setId(1L);
        ticket1.setEmail(email);
        Ticket ticket2 = new Ticket();
        ticket2.setId(2L);
        ticket2.setEmail(email);
        List<Ticket> tickets = new ArrayList<>();
        tickets.add(ticket1);
        tickets.add(ticket2);

        Conversation conversation1 = new Conversation();
        conversation1.setReadByUser(false);
        Conversation conversation2 = new Conversation();
        conversation2.setReadByUser(false);
        List<Conversation> conversations = new ArrayList<>();
        conversations.add(conversation1);
        conversations.add(conversation2);

        when(ticketRepository.findByEmail(email)).thenReturn(tickets);
        when(conversationRepository.findByTicketIdAndReadByUserIsFalse(anyLong())).thenReturn(conversations);

        List<Ticket> result = ticketService.fetchTicketByEmail(email);

        assertEquals(2, result.size());
        assertEquals(2, result.get(0).getUnreadMsgCount());
        assertEquals(2, result.get(1).getUnreadMsgCount());
    }

    @Test
     void testUpdateTicketById() throws MessagingException {
        Ticket existingTicket = new Ticket();
        existingTicket.setId(1L);
        existingTicket.setStatus("open");

        when(ticketRepository.findById(1L)).thenReturn(Optional.of(existingTicket));
        when(ticketRepository.save(any(Ticket.class))).thenAnswer(invocation -> invocation.getArgument(0));
        doNothing().when(emailService).updateTicketEmail(any(Ticket.class));

        Ticket updatedTicket = new Ticket();
        updatedTicket.setStatus("progress");
        updatedTicket.setComments("Some comments");
        updatedTicket.setModifiedBy("Admin");

        Ticket result = ticketService.updateTicketById(updatedTicket, 1L);

        assertEquals(updatedTicket.getStatus(), result.getStatus());
        assertEquals(updatedTicket.getComments(), result.getComments());
        assertEquals(updatedTicket.getModifiedBy(), result.getModifiedBy());
        verify(emailService, times(1)).updateTicketEmail(any(Ticket.class));
    }
}
