package com.it.helpdesk.server.security;

class ConversationAuthenticationTest {
}
