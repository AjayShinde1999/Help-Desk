package com.it.helpdesk.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItHelpDeskServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
