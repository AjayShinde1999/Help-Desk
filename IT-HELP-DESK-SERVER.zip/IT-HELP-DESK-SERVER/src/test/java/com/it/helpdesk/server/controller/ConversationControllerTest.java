package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.security.ConversationAuthentication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ConversationControllerTest {

    @Mock
    private ConversationAuthentication conversationAuthentication;

    @InjectMocks
    private ConversationController conversationController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFetchAllConversationByTicketId_Success() throws Exception {
        Jwt jwt = mock(Jwt.class);
        long ticketId = 1L;
        Conversation conversation1 = new Conversation();
        Conversation conversation2 = new Conversation();
        List<Conversation> expectedConversations = Arrays.asList(conversation1, conversation2);

        when(conversationAuthentication.authenticateUsersForFetchAllConversation(jwt, ticketId))
                .thenReturn(expectedConversations);

        List<Conversation> actualConversations = conversationController.fetchAllConversationByTicketId(jwt, ticketId);

        assertNotNull(actualConversations, "The list of conversations should not be null");
        assertEquals(expectedConversations.size(), actualConversations.size(), "The size of the returned conversations list should be the same as expected");
        assertEquals(expectedConversations, actualConversations, "The returned conversations should match the expected list");
    }
}
