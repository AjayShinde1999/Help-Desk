package com.it.helpdesk.server.security;

import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.DropdownValues;
import com.it.helpdesk.server.service.TicketService;
import com.it.helpdesk.server.utils.AppConstant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.oauth2.jwt.Jwt;

import javax.mail.MessagingException;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TicketAuthenticationTest {

    @Mock
    private TicketService ticketService;

    @InjectMocks
    private TicketAuthentication ticketAuthentication;

    private static final String CLIENT_ID = "mockedClientId";

    private static final String TEST_EMAIL = "test@example.com";

    @Mock
    private Jwt jwt;

    @BeforeEach
     void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
     void testAuthenticateUserForFetchAllTickets_WriteAndHrRoles() {
        Jwt jwt = mockJwt1(List.of("ticket.write", "ticket.hr"), null, null);
        lenient().when(ticketService.fetchAllTickets()).thenReturn(Collections.emptyList());
        List<Ticket> result = ticketAuthentication.authenticateUserForFetchAllTickets(jwt);
        assertEquals(Collections.emptyList(), result);
    }

    private Jwt mockJwt1(List<String> roles, Object audience, String email) {
        Jwt jwt = Jwt.withTokenValue("token")
                .header("alg", "none")
                .claim("roles", roles)
                .claim("aud", audience)
                .claim("email", email)
                .build();
        return jwt;
    }

    @Test
     void testAuthenticateUserForFetchAllTickets_WriteRole() {
        Jwt jwt = mockJwt1(List.of("ticket.write"), null, TEST_EMAIL);
        lenient().when(ticketService.fetchTicketsByCategoryOtherThanHR(TEST_EMAIL)).thenReturn(Collections.emptyList());
        List<Ticket> result = ticketAuthentication.authenticateUserForFetchAllTickets(jwt);
        assertEquals(Collections.emptyList(), result);
    }


    @Test
     void testAuthenticateUserForFetchAllTickets_HrRole() {
        Jwt jwt = mockJwt1(List.of("ticket.hr"), null, TEST_EMAIL);
        lenient().when(ticketService.fetchTicketByHrIssue(TEST_EMAIL)).thenReturn(Collections.emptyList());
        List<Ticket> result = ticketAuthentication.authenticateUserForFetchAllTickets(jwt);
        assertEquals(Collections.emptyList(), result);
    }


    @Test
     void testAuthenticateUserForFetchAllTickets_NullRoles() throws MessagingException, IOException {
        Jwt jwt = mock(Jwt.class);
        assertThrows(AccessDeniedException.class, () -> {
            ticketAuthentication.authenticateUserForFetchAllTickets(jwt);
        });
    }


    @Test
     void testAuthenticateUserForFetchAllTickets_ClientAudience() {
        List<String> roles = Collections.singletonList(AppConstant.TICKET_WRITE);
        Object audience = List.of(CLIENT_ID);
        String email = TEST_EMAIL;
        Jwt jwt = mockJwt_ClientAudience(roles, audience, email);
        lenient().when(ticketService.fetchAllTickets()).thenReturn(Collections.emptyList());
        List<Ticket> result = ticketAuthentication.authenticateUserForFetchAllTickets(jwt);
        assertEquals(Collections.emptyList(), result);
    }
    private Jwt mockJwt_ClientAudience(List<String> roles, Object audience, String email) {
        Map<String, Object> headers = new HashMap<>();
        headers.put("typ", "JWT");
        Map<String, Object> claims = new HashMap<>();
        claims.put(AppConstant.ROLE, roles);
        claims.put(AppConstant.AUDIENCE, audience);
        claims.put(AppConstant.EMAIL, email);
        String tokenValue = "exampleToken";
        Instant issuedAt = Instant.now();
        Instant expiresAt = issuedAt.plusSeconds(3600);
        return new Jwt(tokenValue, issuedAt, expiresAt, headers, claims);
    }

    @Test
     void testAuthenticateUserForFetchDropdownValues_Success() {
        Map<String, Object> headers = new HashMap<>();
        headers.put("alg", "none");
        headers.put("typ", "JWT");
        Map<String, Object> claims = new HashMap<>();
        claims.put(AppConstant.AUDIENCE, Collections.singletonList(CLIENT_ID));
        Jwt jwt = new Jwt("tokenValue", Instant.now(), Instant.now().plus(Duration.ofHours(1)), headers, claims);
        TicketAuthentication ticketAuthentication = mock(TicketAuthentication.class);
        DropdownValues expectedDropdownValues = new DropdownValues(Arrays.asList("high", "medium", "low"),
                Arrays.asList("hardware issue", "software issue", "hr related issue", "others"));
        when(ticketAuthentication.authenticateUserForFetchDropdownValues((jwt)))
                .thenReturn(expectedDropdownValues);
        DropdownValues dropdownValues = ticketAuthentication.authenticateUserForFetchDropdownValues(jwt);
        assertNotNull(dropdownValues);
        List<String> expectedPriorities = Arrays.asList("high", "medium", "low");
        List<String> expectedCategories = Arrays.asList("hardware issue", "software issue", "hr related issue", "others");
        assertEquals(expectedPriorities, dropdownValues.getPriority());
        assertEquals(expectedCategories, dropdownValues.getCategory());
    }

}


