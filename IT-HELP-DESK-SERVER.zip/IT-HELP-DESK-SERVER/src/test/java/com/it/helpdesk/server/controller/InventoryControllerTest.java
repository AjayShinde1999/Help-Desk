package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.payload.InventoryDto;
import com.it.helpdesk.server.security.InventoryAuthentication;
import com.it.helpdesk.server.service.InventoryExcelService;
import com.it.helpdesk.server.utils.ExcelResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class InventoryControllerTest {

    @InjectMocks
    private InventoryController inventoryController;

    @Mock
    private InventoryAuthentication inventoryAuthentication;

    @Mock
    private InventoryExcelService inventoryExcelService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSaveInventoryWithAttachment_Success() throws IOException {
        Jwt jwt = mock(Jwt.class);
        InventoryDto inventoryDto = mock(InventoryDto.class);
        Inventory inventory = new Inventory();
        when(inventoryAuthentication.authenticateAdminForSaveInventoryWithAttachment(jwt, inventoryDto)).thenReturn(inventory);

        Inventory savedInventory = inventoryController.saveInventoryWithAttachment(jwt, inventoryDto);
        assertNotNull(savedInventory);
        assertEquals(inventory, savedInventory);
    }

    @Test
    void testSaveInventoryWithOutAttachment_Success() throws IOException {
        Jwt jwt = mock(Jwt.class);
        Inventory inventory = new Inventory();
        when(inventoryAuthentication.authenticateAdminForSaveInventoryWithOutAttachment(jwt, inventory)).thenReturn(inventory);

        Inventory savedInventory = inventoryController.saveInventoryWithOutAttachment(jwt, inventory);

        assertNotNull(savedInventory);
        assertEquals(inventory, savedInventory);
    }

    @Test
    void testFetchAllInventory_Success() throws AccessDeniedException {
        Jwt jwt = mock(Jwt.class);
        List<Inventory> inventoryList = new ArrayList<>();
        Inventory inventory1 = new Inventory();
        inventory1.setEmployeeName("test employee");
        inventory1.setEmployeeId("EMP123");
        inventory1.setMake("Dell");
        inventory1.setModel("Latitude");
        inventory1.setProcessor("Intel Core i5");
        inventory1.setRamSize("8GB");
        inventory1.setStorageSize("256GB SSD");
        inventory1.setSerialNo("SN123456");
        inventory1.setAssetTagId("TAG789");
        inventory1.setWarranty("1 year");
        inventory1.setAgreement("Service Agreement XYZ");
        inventory1.setAttachment("attachment_path");
        inventory1.setAssigned(true);
        inventory1.setAdditionalDetails("Additional details here");
        inventory1.setLastUpdatedDate("2024-04-21");
        inventory1.setExpectedReturnDate("2024-05-21");
        inventory1.setDeviceType("Laptop");

        inventoryList.add(inventory1);

        Inventory inventory2 = new Inventory();

        inventory2.setEmployeeName("test user");
        inventory2.setEmployeeId("EMP123");
        inventory2.setMake("Dell");
        inventory2.setModel("Latitude");
        inventory2.setProcessor("Intel Core i5");
        inventory2.setRamSize("8GB");
        inventory2.setStorageSize("256GB SSD");
        inventory2.setSerialNo("SN123456");
        inventory2.setAssetTagId("TAG789");
        inventory2.setWarranty("1 year");
        inventory2.setAgreement("Service Agreement XYZ");
        inventory2.setAttachment("attachment_path");
        inventory2.setAssigned(true);
        inventory2.setAdditionalDetails("Additional details here");
        inventory2.setLastUpdatedDate("2024-04-21");
        inventory2.setExpectedReturnDate("2024-05-21");
        inventory2.setDeviceType("Laptop");
        inventoryList.add(inventory2);

        when(inventoryAuthentication.authenticateAdminForFetchAllInventory(jwt)).thenReturn(inventoryList);
        List<Inventory> fetchedInventoryList = inventoryController.fetchAllInventory(jwt);
        assertEquals(inventoryList.size(), fetchedInventoryList.size());
    }

    @Test
    void testUpdateInventoryWithOutAttachment_Success() throws IOException {
        Jwt jwt = mock(Jwt.class);
        long Id = 1L;
        Inventory inventory = new Inventory();
        when(inventoryAuthentication.authenticateAdminForUpdateInventoryWithOutAttachment(jwt, inventory, Id)).thenReturn(inventory);
        Inventory updatedInventory = inventoryController.updateInventoryWithOutAttachment(jwt, inventory, Id);
        assertNotNull(updatedInventory);
    }

    @Test
    void testUpdateInventoryWithAttachment_Success() throws IOException {
        Jwt jwt = mock(Jwt.class);
        long inventoryId = 1L;
        InventoryDto inventoryDto = new InventoryDto();

        when(inventoryAuthentication.authenticateAdminForUpdateInventoryWithAttachment(jwt, inventoryDto, inventoryId)).thenReturn(mock(Inventory.class));
        Inventory updatedInventory = inventoryController.updateInventoryWithAttachment(jwt, inventoryDto, inventoryId);
        assertNotNull(updatedInventory);
    }

    @Test
    void testDownloadArchive_Success() throws IOException {
        Jwt jwt = mock(Jwt.class);
        ExcelResponse excelResponse = mock(ExcelResponse.class);
        when(inventoryExcelService.exportInventoryToExcel()).thenReturn(excelResponse);
        ExcelResponse response = inventoryController.downloadArchive(jwt);
        assertNotNull(response);
        assertEquals(excelResponse, response);
    }

}
