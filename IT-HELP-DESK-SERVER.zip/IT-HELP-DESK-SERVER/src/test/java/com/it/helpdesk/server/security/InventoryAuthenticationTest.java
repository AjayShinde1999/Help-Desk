package com.it.helpdesk.server.security;


import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.payload.InventoryDto;
import com.it.helpdesk.server.service.InventoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class InventoryAuthenticationTest {

    @Mock
    private InventoryService inventoryService;

    @InjectMocks
    private InventoryAuthentication inventoryAuthentication;

    private Jwt jwt;

    @BeforeEach
    void setUp() {
        jwt = mock(Jwt.class);
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testAuthenticateAdminForSaveInventoryWithAttachment() throws IOException {
        InventoryDto inventoryDto = new InventoryDto();
        inventoryDto.setId(1L);
        inventoryDto.setEmployeeName("John Doe");
        inventoryDto.setEmployeeId("EMP123");
        inventoryDto.setMake("Dell");
        inventoryDto.setModel("Latitude");
        inventoryDto.setProcessor("Intel Core i5");
        inventoryDto.setRamSize("8GB");
        inventoryDto.setStorageSize("256GB SSD");
        inventoryDto.setSerialNo("SN123456");
        inventoryDto.setAssetTagId("TAG789");
        inventoryDto.setWarranty("1 year");
        inventoryDto.setAgreement("Service Agreement XYZ");
        inventoryDto.setAttachment(mock(MultipartFile.class));
        inventoryDto.setAssigned(true);
        inventoryDto.setAdditionalDetails("Additional details here");
        inventoryDto.setLastUpdatedDate("2024-04-21");
        inventoryDto.setExpectedReturnDate("2024-05-21");
        inventoryDto.setDeviceType("Laptop");

        Inventory inventory = new Inventory();
        inventory.setId(1L);
        inventory.setEmployeeName("John Doe");
        inventory.setEmployeeId("EMP123");
        inventory.setMake("Dell");
        inventory.setModel("Latitude");
        inventory.setProcessor("Intel Core i5");
        inventory.setRamSize("8GB");
        inventory.setStorageSize("256GB SSD");
        inventory.setSerialNo("SN123456");
        inventory.setAssetTagId("TAG789");
        inventory.setWarranty("1 year");
        inventory.setAgreement("Service Agreement XYZ");
        inventory.setAttachment("attachment_path");
        inventory.setAssigned(true);
        inventory.setAdditionalDetails("Additional details here");
        inventory.setLastUpdatedDate("2024-04-21");
        inventory.setExpectedReturnDate("2024-05-21");
        inventory.setDeviceType("Laptop");

        when(jwt.getClaim("roles")).thenReturn(Arrays.asList("ticket.write"));

        when(inventoryService.saveOneInventory(inventoryDto)).thenReturn(inventory);
        Inventory result = inventoryAuthentication.authenticateAdminForSaveInventoryWithAttachment(jwt, inventoryDto);
        assertEquals(inventory, result);
        verify(inventoryService).saveOneInventory(inventoryDto);
        when(jwt.getClaim("roles")).thenReturn(Arrays.asList("user.read"));
        assertThrows(AccessDeniedException.class, () -> inventoryAuthentication.authenticateAdminForSaveInventoryWithAttachment(jwt, inventoryDto));
    }

    @Test
    void testAuthenticateAdminForSaveInventoryWithoutAttachment() throws AccessDeniedException {
        Inventory inventory = new Inventory();
        inventory.setId(1L);
        inventory.setEmployeeName("John Doe");
        inventory.setEmployeeId("EMP123");
        inventory.setMake("Dell");
        inventory.setModel("Latitude");
        inventory.setProcessor("Intel Core i5");
        inventory.setRamSize("8GB");
        inventory.setStorageSize("256GB SSD");
        inventory.setSerialNo("SN123456");
        inventory.setAssetTagId("TAG789");
        inventory.setWarranty("1 year");
        inventory.setAgreement("Service Agreement XYZ");
        inventory.setAttachment("attachment_path");
        inventory.setAssigned(true);
        inventory.setAdditionalDetails("Additional details here");
        inventory.setLastUpdatedDate("2024-04-21");
        inventory.setExpectedReturnDate("2024-05-21");
        inventory.setDeviceType("Laptop");

        when(jwt.getClaim("roles")).thenReturn(Arrays.asList("ticket.write"));

        when(inventoryService.saveOneInventoryWithoutAttachment(inventory)).thenReturn(inventory);
        Inventory result = inventoryAuthentication.authenticateAdminForSaveInventoryWithOutAttachment(jwt, inventory);
        assertEquals(inventory, result);
        verify(inventoryService).saveOneInventoryWithoutAttachment(inventory);

        when(jwt.getClaim("roles")).thenReturn(Arrays.asList("user.read"));
        assertThrows(AccessDeniedException.class, () -> inventoryAuthentication.authenticateAdminForSaveInventoryWithOutAttachment(jwt, inventory));
    }

    @Test
    void testAuthenticateAdminForFetchAllInventory() throws AccessDeniedException {

        List<Inventory> inventories = new ArrayList<>();
        Inventory inventory1 = new Inventory();
        inventory1.setEmployeeName("swamesha");
        inventory1.setEmployeeId("EMP123");
        inventory1.setMake("Dell");
        inventory1.setModel("Latitude");
        inventory1.setProcessor("Intel Core i5");
        inventory1.setRamSize("8GB");
        inventory1.setStorageSize("256GB SSD");
        inventory1.setSerialNo("SN123456");
        inventory1.setAssetTagId("TAG789");
        inventory1.setWarranty("1 year");
        inventory1.setAgreement("Service Agreement XYZ");
        inventory1.setAttachment("attachment_path");
        inventory1.setAssigned(true);
        inventory1.setAdditionalDetails("Additional details here");
        inventory1.setLastUpdatedDate("2024-04-21");
        inventory1.setExpectedReturnDate("2024-05-21");
        inventory1.setDeviceType("Laptop");

        inventories.add(inventory1);

        Inventory inventory2 = new Inventory();

        inventory2.setEmployeeName("swamesha");
        inventory2.setEmployeeId("EMP123");
        inventory2.setMake("Dell");
        inventory2.setModel("Latitude");
        inventory2.setProcessor("Intel Core i5");
        inventory2.setRamSize("8GB");
        inventory2.setStorageSize("256GB SSD");
        inventory2.setSerialNo("SN123456");
        inventory2.setAssetTagId("TAG789");
        inventory2.setWarranty("1 year");
        inventory2.setAgreement("Service Agreement XYZ");
        inventory2.setAttachment("attachment_path");
        inventory2.setAssigned(true);
        inventory2.setAdditionalDetails("Additional details here");
        inventory2.setLastUpdatedDate("2024-04-21");
        inventory2.setExpectedReturnDate("2024-05-21");
        inventory2.setDeviceType("Laptop");

        inventories.add(inventory2);

        when(jwt.getClaim("roles")).thenReturn(Arrays.asList("ticket.write"));
        when(inventoryService.fetchAllInventory()).thenReturn(inventories);
        List<Inventory> result = inventoryAuthentication.authenticateAdminForFetchAllInventory(jwt);
        assertEquals(inventories, result);
        verify(inventoryService).fetchAllInventory();
    }

    @Test
    void testAuthenticateAdminForInventoryUpdate() throws IOException {
        Jwt jwt = mock(Jwt.class);
        Inventory inventory = new Inventory();
        long id = 1L;
        List<String> writeRoles = Collections.singletonList("ticket.write");
        when(jwt.getClaim("roles")).thenReturn(writeRoles);
        when(inventoryService.updateInventory(inventory, id)).thenReturn(inventory);

        Inventory result = inventoryAuthentication.authenticateAdminForUpdateInventoryWithOutAttachment(jwt, inventory, id);
        assertNotNull(result);
        assertEquals(inventory, result);
        verify(inventoryService).updateInventory(inventory, id);

        List<String> readRoles = Collections.singletonList("user.read");
        when(jwt.getClaim("roles")).thenReturn(readRoles);
        assertThrows(AccessDeniedException.class, () -> inventoryAuthentication.authenticateAdminForUpdateInventoryWithOutAttachment(jwt, inventory, id));
    }


    @Test
    void testAuthenticateAdminForUpdateInventoryWithAttachment() throws IOException {

        Jwt jwt = mock(Jwt.class);
        InventoryDto inventoryDto = new InventoryDto();
        inventoryDto.setId(1L);
        Inventory inventory = new Inventory();
        long id = 1L;

        List<String> writeRoles = Collections.singletonList("ticket.write");
        when(jwt.getClaim("roles")).thenReturn(writeRoles);
        when(inventoryService.updateInventoryWithImage(inventoryDto, id)).thenReturn(inventory);

        Inventory result = inventoryAuthentication.authenticateAdminForUpdateInventoryWithAttachment(jwt, inventoryDto, id);
        assertNotNull(result);
        assertEquals(inventory, result);
        verify(inventoryService).updateInventoryWithImage(inventoryDto, id);
        List<String> readRoles = Collections.singletonList("user.read");
        when(jwt.getClaim("roles")).thenReturn(readRoles);
        assertThrows(AccessDeniedException.class, () -> inventoryAuthentication.authenticateAdminForUpdateInventoryWithAttachment(jwt, inventoryDto, id));
    }
}
