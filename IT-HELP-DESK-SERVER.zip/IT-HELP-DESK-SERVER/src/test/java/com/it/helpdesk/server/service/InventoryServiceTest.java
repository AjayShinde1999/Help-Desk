package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.repository.InventoryRepository;
import com.it.helpdesk.server.service.impl.InventoryServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class InventoryServiceTest {

    @Mock
    private InventoryRepository inventoryRepository;

    @InjectMocks
    private InventoryServiceImpl inventoryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSaveOneInventoryWithoutAttachment() {
        Inventory inventory = new Inventory();
        inventory.setEmployeeName("test user");
        inventory.setEmployeeId("3KBLR1250");
        inventory.setMake("test make");
        inventory.setModel("test model");
        inventory.setProcessor("intel i5");
        inventory.setRamSize("8GB");
        inventory.setStorageSize("512GB");
        inventory.setSerialNo("123456");
        inventory.setAssetTagId("TAG123");
        inventory.setWarranty("1 year");
        inventory.setAgreement("AgreementDetails");
        inventory.setAttachment(null);
        inventory.setAssigned(true);
        inventory.setAdditionalDetails("AdditionalDetails");
        inventory.setLastUpdatedDate("2022-01-01");
        inventory.setExpectedReturnDate("2022-02-01");
        inventory.setDeviceType("Laptop");

        when(inventoryRepository.existsBySerialNo(anyString())).thenReturn(false);
        when(inventoryRepository.existsByAssetTagId(anyString())).thenReturn(false);
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);

        Inventory savedInventory = inventoryService.saveOneInventoryWithoutAttachment(inventory);
        assertNotNull(savedInventory);
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
    }

    @Test
    void testFetchAllInventory() {
        Inventory inventory1 = new Inventory();

        inventory1.setEmployeeName("test employee");
        inventory1.setEmployeeId("3KBLR1243");
        inventory1.setMake("test make");
        inventory1.setModel("test model");
        inventory1.setProcessor("ExampleProcessor");
        inventory1.setRamSize("8GB");
        inventory1.setStorageSize("512GB");
        inventory1.setSerialNo("123456");
        inventory1.setAssetTagId("TAG123");
        inventory1.setWarranty("1 year");
        inventory1.setAgreement("AgreementDetails");
        inventory1.setAssigned(true);
        inventory1.setAdditionalDetails("AdditionalDetails");
        inventory1.setLastUpdatedDate("2022-01-01");
        inventory1.setExpectedReturnDate("2022-02-01");
        inventory1.setDeviceType("Laptop");

        Inventory inventory2 = new Inventory();

        inventory2.setEmployeeName("test user");
        inventory2.setEmployeeId("3KBLR1235");
        inventory2.setMake("test make");
        inventory2.setModel("inventory");
        inventory2.setProcessor("ExampleProcessor");
        inventory2.setRamSize("8GB");
        inventory2.setStorageSize("512GB");
        inventory2.setSerialNo("123456");
        inventory2.setAssetTagId("TAG123");
        inventory2.setWarranty("1 year");
        inventory2.setAgreement("AgreementDetails");
        inventory2.setAssigned(true);
        inventory2.setAdditionalDetails("AdditionalDetails");
        inventory2.setLastUpdatedDate("2022-01-01");
        inventory2.setExpectedReturnDate("2022-02-01");
        inventory2.setDeviceType("Laptop");

        List<Inventory> mockInventoryList = Arrays.asList(inventory1, inventory2);
        when(inventoryRepository.findAll()).thenReturn(mockInventoryList);

        List<Inventory> fetchedInventoryList = inventoryService.fetchAllInventory();

        assertEquals(mockInventoryList.size(), fetchedInventoryList.size());
        assertEquals(mockInventoryList.get(0).getSerialNo(), fetchedInventoryList.get(0).getSerialNo());
        assertEquals(mockInventoryList.get(0).getAssetTagId(), fetchedInventoryList.get(0).getAssetTagId());
        assertEquals(mockInventoryList.get(1).getSerialNo(), fetchedInventoryList.get(1).getSerialNo());
        assertEquals(mockInventoryList.get(1).getAssetTagId(), fetchedInventoryList.get(1).getAssetTagId());

        verify(inventoryRepository, times(1)).findAll();
    }

    @Test
    void testUpdateInventory() {
        long id = 1L;
        Inventory existingInventory = new Inventory();
        existingInventory.setId(id);
        existingInventory.setSerialNo("ABC123");
        existingInventory.setAssetTagId("TAG456");
        existingInventory.setEmployeeName("swamesha");
        existingInventory.setEmployeeId("EMP001");
        existingInventory.setMake("Dell");
        existingInventory.setModel("inventory");
        existingInventory.setProcessor("Intel Core i5");
        existingInventory.setRamSize("8GB");
        existingInventory.setStorageSize("256GB SSD");
        existingInventory.setWarranty("1 year");
        existingInventory.setAgreement("Service agreement");
        existingInventory.setAttachment("file.txt");
        existingInventory.setAssigned(true);
        existingInventory.setAdditionalDetails("Additional details");
        existingInventory.setLastUpdatedDate(String.valueOf(LocalDate.now()));
        existingInventory.setExpectedReturnDate(String.valueOf(LocalDate.now().plusDays(30)));
        existingInventory.setDeviceType("Laptop");

        Inventory updatedInventory = new Inventory();
        updatedInventory.setEmployeeName("Ramesha");
        updatedInventory.setRamSize("10GB");
        updatedInventory.setSerialNo("1234");
        updatedInventory.setAssetTagId("tag123");

        when(inventoryRepository.findById(id)).thenReturn(Optional.of(existingInventory));
        when(inventoryRepository.findBySerialNo(anyString())).thenReturn(null);
        when(inventoryRepository.findByAssetTagId(anyString())).thenReturn(null);
        when(inventoryRepository.save(existingInventory)).thenReturn(updatedInventory);

        Inventory result = inventoryService.updateInventory(updatedInventory, id);

        assertEquals(updatedInventory.getEmployeeName(), result.getEmployeeName());
        assertEquals(updatedInventory.getRamSize(), result.getRamSize());
        reset(inventoryRepository);
        when(inventoryRepository.findById(id)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> inventoryService.updateInventory(updatedInventory, id));
    }
}
