package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Skills;
import com.it.helpdesk.server.repository.SkillsRepository;
import com.it.helpdesk.server.service.impl.SkillsServiceImpl;
import com.it.helpdesk.server.utils.SkillsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class SkillsServiceTest {

    @Mock
    private SkillsRepository skillsRepository;

    @InjectMocks
    private SkillsServiceImpl skillsService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSaveSkills() {

        Skills skill1 = new Skills();
        skill1.setId(1L);
        skill1.setName("Java");

        Skills skill2 = new Skills();
        skill2.setId(2L);
        skill2.setName("Spring Boot");

        List<Skills> skillsToSave = Arrays.asList(skill1, skill2);
        when(skillsRepository.saveAll(skillsToSave)).thenReturn(skillsToSave);
        List<Skills> savedSkills = skillsService.saveSkills(skillsToSave);

        assertEquals(skillsToSave.size(), savedSkills.size());
        for (int i = 0; i < skillsToSave.size(); i++) {
            assertEquals(skillsToSave.get(i).getId(), savedSkills.get(i).getId());
            assertEquals(skillsToSave.get(i).getName(), savedSkills.get(i).getName());
        }
        verify(skillsRepository, times(1)).saveAll(skillsToSave);
    }

    @Test
    void testSearchSkills() {

        Skills skill1 = new Skills();
        skill1.setId(1L);
        skill1.setName("Java");

        Skills skill2 = new Skills();
        skill2.setId(2L);
        skill2.setName("Spring Boot");

        List<Skills> skillsList = Arrays.asList(skill1, skill2);
        when(skillsRepository.findAll()).thenReturn(skillsList);
        SkillsResponse response = skillsService.searchSkills();

        verify(skillsRepository, times(1)).findAll();
        assertEquals(skillsList.size(), response.getSkills().size());
        for(int i=0; i<skillsList.size(); i++){
            assertEquals(skillsList.get(i).getName(),response.getSkills().get(i));
        }
    }
}

