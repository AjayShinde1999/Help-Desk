package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.InventoryDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface InventoryService {
    Inventory saveOneInventory(InventoryDto inventoryDto) throws IOException;

    Inventory saveOneInventoryWithoutAttachment(Inventory inventory);

    List<Inventory> fetchAllInventory();

    Inventory updateInventory(Inventory inventory, long id);

    Inventory updateInventoryWithImage(InventoryDto inventoryDto, long id) throws IOException;
}
