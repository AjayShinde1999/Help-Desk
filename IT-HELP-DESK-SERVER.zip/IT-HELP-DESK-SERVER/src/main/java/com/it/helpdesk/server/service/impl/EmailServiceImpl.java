package com.it.helpdesk.server.service.impl;

import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

@Service
public class EmailServiceImpl implements EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String emailFrom;

    @Value("${admin.email.id}")
    private String adminEmail;

    @Value("${hr.email.id}")
    private String hrEmail;

    @Override
    public void sendEmail(String toEmail, String subject, String text) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setFrom(emailFrom);
        helper.setTo(toEmail);
        helper.setSubject(subject);
        helper.setText(text);
        javaMailSender.send(message);
    }

    public void createTicketEmail(Ticket ticket) throws MessagingException {
        String emailTextAdmin = emailTextForAdmin(ticket);
        String emailTextHR = emailTextForHR(ticket);
        String emailTextUser = emailTextForUser(ticket);
        String subject = "New Ticket Raised - Ticket No: ";
        String subjectAdminHr = " - New Ticket Raised by ";

        if (ticket.getCategory().equals("hr related issue")) {
            if (ticket.getEmail().equals(hrEmail)) {
                sendEmail(ticket.getEmail(), subject + ticket.getTicketNo(), emailTextUser);
            } else {
                sendEmail(ticket.getEmail(), subject + ticket.getTicketNo(), emailTextUser);
                sendEmail(hrEmail, ticket.getTicketNo() + subjectAdminHr + ticket.getEmail(), emailTextHR);
            }
        } else {
            if (ticket.getEmail().equals(adminEmail)) {
                sendEmail(ticket.getEmail(), subject + ticket.getTicketNo(), emailTextUser);
            } else {
                sendEmail(ticket.getEmail(), subject + ticket.getTicketNo(), emailTextUser);
                sendEmail(adminEmail, ticket.getTicketNo() + subjectAdminHr + ticket.getEmail(), emailTextAdmin);
            }
        }
    }

    String emailTextForAdmin(Ticket ticket) {
        return String.format("Dear Admin,\n" +
                        "\n" +
                        "A new ticket has been raised with the following details:\n" +
                        "\n" +
                        "Ticket ID: %s\n" +
                        "Subject: %s\n" +
                        "\n" +
                        "Sender's Details:\n" +
                        "      1. Name: %s\n" +
                        "      2. Email: %s\n" +
                        "\n" +
                        "Issue/Request Details:\n" +
                        "      1. Date Raised: %s\n" +
                        "      2. Description: %s\n" +
                        "\n" +
                        "We kindly request your prompt attention to resolve the matter. If additional information is required, please reach out to the sender directly." +
                        "\n" +
                        "\n" +
                        "Note: This is an auto-generated mail. Please do not reply.",
                ticket.getTicketNo(),
                ticket.getSubject(),
                ticket.getUsername(),
                ticket.getEmail(),
                ticket.getDate(),
                ticket.getDescription());
    }

    String emailTextForHR(Ticket ticket) {
        return String.format("Dear HR,\n" +
                        "\n" +
                        "A new ticket has been raised with the following details:\n" +
                        "\n" +
                        "Ticket ID: %s\n" +
                        "Subject: %s\n" +
                        "\n" +
                        "Sender's Details:\n" +
                        "      1. Name: %s\n" +
                        "      2. Email: %s\n" +
                        "\n" +
                        "Issue/Request Details:\n" +
                        "      1. Date Raised: %s\n" +
                        "      2. Description: %s\n" +
                        "\n" +
                        "We kindly request your prompt attention to resolve the matter. If additional information is required, please reach out to the sender directly." +
                        "\n" +
                        "\n" +
                        "Note: This is an auto-generated mail. Please do not reply.",
                ticket.getTicketNo(),
                ticket.getSubject(),
                ticket.getUsername(),
                ticket.getEmail(),
                ticket.getDate(),
                ticket.getDescription());
    }

    String emailTextForUser(Ticket ticket) {
        return String.format("Dear %s,\n" +
                        "\n" +
                        "I hope this email finds you well. We would like to inform you that a ticket has been raised based on the recent request or issue you submitted. Below are the details for your reference:\n" +
                        "\n" +
                        "Ticket ID: %s\n" +
                        "Subject: %s\n" +
                        "\n" +
                        "Sender's Details:\n" +
                        "      1. Name: %s\n" +
                        "      2. Email: %s\n" +
                        "\n" +
                        "Issue/Request Details:\n" +
                        "      1. Date Raised: %s\n" +
                        "      2. Description: %s\n" +
                        "\n" +
                        "Our team is actively working on resolving your concern and will provide updates as progress is made. Please feel free to reach out if you have any additional information to share or if you have any questions regarding the ticket. Thank you for bringing this matter to our attention, and we appreciate your patience as we work to resolve it." +
                        "\n" +
                        "\n" +
                        "Note: This is an auto-generated mail. Please do not reply.",
                ticket.getUsername(),
                ticket.getTicketNo(),
                ticket.getSubject(),
                ticket.getUsername(),
                ticket.getEmail(),
                ticket.getDate(),
                ticket.getDescription());
    }

    @Override
    public void updateTicketEmail(Ticket ticket) throws MessagingException {

        if (ticket.getStatus().equals("progress")) {
            acceptMailMessage(ticket);
        } else if (ticket.getStatus().equals("resolved")) {
            resolvedMailMessage(ticket);
        } else {
            rejectedMailMessage(ticket);
        }
    }

    public void acceptMailMessage(Ticket ticket) throws MessagingException {
        sendEmail(ticket.getEmail(), "[ Ticket No: #" + ticket.getTicketNo() + " ] - ACCEPTED", String.format("Dear %s,\n" +
                        "\n" +
                        "We would like to inform you that your recently raised ticket has been ACCEPTED by our support team. Below are the details for your reference:\n" +
                        "\n" +
                        "Ticket ID: %s\n" +
                        "Subject: %s\n" +
                        "\n" +
                        "Issue/Request Details:\n" +
                        "      1. Accepted Date: %s\n" +
                        "      2. Description: %s\n" +
                        "\n" +
                        "Thank you for your patience and understanding as we work to resolve your issue promptly. Our team is actively working on resolving your concern and will provide updates as progress is made. Please feel free to reach out if you have any questions regarding the ticket." +
                        "\n" +
                        "\n" +
                        "Note: This is an auto-generated mail. Please do not reply.",
                ticket.getUsername(),
                ticket.getTicketNo(),
                ticket.getSubject(),
                ticket.getDate(),
                ticket.getDescription()));
    }

    public void resolvedMailMessage(Ticket ticket) throws MessagingException {
        sendEmail(ticket.getEmail(), "[ Ticket No: #" + ticket.getTicketNo() + " ] - RESOLVED", String.format("Dear " + ticket.getUsername() + ",\n" +
                "\n" +
                "I hope this email finds you well. We are pleased to inform you that your recent ticket, with ID #" + ticket.getTicketNo() + " and the subject [ " + ticket.getSubject() + " ] has been successfully RESOLVED.\n" +
                "\n" +
                "Resolved Ticket Details:\n" +
                "      1. Resolved Date: " + ticket.getDate() + "\n" +
                "      2. Solution/Comments: " + ticket.getComments() + "\n" +
                "\n" +
                "We appreciate your patience and cooperation throughout this process. Thank you for bringing this matter to our attention, and we look forward to continuing to provide excellent service in the future.") +
                "\n" +
                "\n" +
                "Note: This is an auto-generated mail. Please do not reply.");

    }

    public void rejectedMailMessage(Ticket ticket) throws MessagingException {
        sendEmail(ticket.getEmail(), "[ Ticket No: #" + ticket.getTicketNo() + " ] - REJECTED", String.format("Dear " + ticket.getUsername() + ",\n" +
                "\n" +
                "This it to inform you that your recent ticket, with ID #" + ticket.getTicketNo() + " and the subject [" + ticket.getSubject() + "] has been reviewed and unfortunately has been REJECTED.\n" +
                "\n" +
                "Rejected Ticket Details:\n" +
                "      1. Rejected Date: " + ticket.getDate() + "\n" +
                "      2. Rejection Reason/comments: " + ticket.getComments() + "\n" +
                "\n" +
                "Regrettably, after careful assessment, we cannot proceed with the requested resolution. If you have questions or additional details, please reach out. We appreciate your understanding, and feel free to submit a new ticket for any further concerns.") +
                "\n" +
                "\n" +
                "Note: This is an auto-generated mail. Please do not reply.");

    }


}