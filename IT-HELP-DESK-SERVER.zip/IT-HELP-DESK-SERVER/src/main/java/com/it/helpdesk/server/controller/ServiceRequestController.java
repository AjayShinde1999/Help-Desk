package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.payload.ServiceRequestDto;
import com.it.helpdesk.server.security.ServiceRequestAuthentication;
import com.it.helpdesk.server.utils.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;

@RestController
@RequestMapping("/helpdesk")
public class ServiceRequestController {

    private ServiceRequestAuthentication serviceRequestAuthentication;

    public ServiceRequestController(ServiceRequestAuthentication serviceRequestAuthentication) {
        this.serviceRequestAuthentication = serviceRequestAuthentication;
    }

    @PostMapping("/service-mail")
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse sendServiceRequestMail(@AuthenticationPrincipal Jwt jwt, @RequestBody ServiceRequestDto serviceRequestDto) throws MessagingException {
        return serviceRequestAuthentication.authenticateAdminForSendServiceRequestMail(jwt, serviceRequestDto);
    }
}
