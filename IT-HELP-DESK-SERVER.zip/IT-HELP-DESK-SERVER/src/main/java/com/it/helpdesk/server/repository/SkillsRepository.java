package com.it.helpdesk.server.repository;

import com.it.helpdesk.server.entity.Skills;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SkillsRepository extends JpaRepository<Skills, Long> {
}
