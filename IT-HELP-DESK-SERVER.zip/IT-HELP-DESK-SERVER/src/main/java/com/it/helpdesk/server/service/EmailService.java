package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Ticket;
import org.springframework.scheduling.annotation.Async;

import javax.mail.MessagingException;

public interface EmailService {

    void sendEmail(String toEmail, String subject, String text) throws MessagingException, MessagingException;

    void createTicketEmail(Ticket ticket) throws MessagingException;

    void updateTicketEmail(Ticket ticket) throws MessagingException;

}
