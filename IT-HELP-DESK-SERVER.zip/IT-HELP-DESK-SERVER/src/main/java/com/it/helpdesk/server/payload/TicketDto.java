package com.it.helpdesk.server.payload;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class TicketDto {

    private Long id;
    private String ticketNo;
    private String username;
    private String email;
    private String subject;
    private String date;
    private String priority;
    private String category;
    private String status;
    private String description;
    private MultipartFile imageUrl;
    private String comments;
    private String ticketCloseDate;
    private String modifiedBy;
    private int unreadMsgCount;
}
