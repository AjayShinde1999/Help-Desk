package com.it.helpdesk.server.service.impl;

import com.it.helpdesk.server.payload.ServiceRequestDto;
import com.it.helpdesk.server.service.EmailServiceRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

@Component
public class EmailServiceRequestImpl implements EmailServiceRequest {

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String emailFrom;

    @Value("${service.request.mail}")
    private String emailTo;

    @Override
    public void sendEmailForServiceRequest(ServiceRequestDto serviceRequestDto) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setFrom(emailFrom);
        helper.setTo(emailTo);
        helper.setSubject(serviceRequestDto.getSubject());
        helper.setText(mailBody(serviceRequestDto));
        javaMailSender.send(message);
    }

        public String mailBody(ServiceRequestDto serviceRequestDto) {
        String body = serviceRequestDto.getMessage();
        String finalBody = body + "\n" + "\n" + "Start Date and Time : [ " + serviceRequestDto.getStartDate() + " || Time : " + serviceRequestDto.getStartTime() + " ]" + "\n" +
                "Expected End Date and Time : [ " + serviceRequestDto.getEndDate() + " || Time : " + serviceRequestDto.getEndTime() + " ]";
        return finalBody;
    }

}
