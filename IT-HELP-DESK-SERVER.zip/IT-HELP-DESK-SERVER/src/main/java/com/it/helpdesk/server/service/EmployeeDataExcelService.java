package com.it.helpdesk.server.service;

import com.it.helpdesk.server.utils.ExcelResponse;

import java.io.IOException;
import java.util.List;

public interface EmployeeDataExcelService {
    ExcelResponse exportEmployeeDataToExcel(List<String> roles) throws IOException;
}
