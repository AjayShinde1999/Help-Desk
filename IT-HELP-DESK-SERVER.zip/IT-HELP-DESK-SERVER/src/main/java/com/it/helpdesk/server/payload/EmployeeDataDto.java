package com.it.helpdesk.server.payload;

import lombok.Data;

@Data
public class EmployeeDataDto {

    private String employeeId;
    private String name;
    private String email;
    private String designation;
    private String experience;
}
