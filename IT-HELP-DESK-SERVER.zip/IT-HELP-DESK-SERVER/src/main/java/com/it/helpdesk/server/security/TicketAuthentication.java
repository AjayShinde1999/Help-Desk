package com.it.helpdesk.server.security;

import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.DropdownValues;
import com.it.helpdesk.server.payload.TicketDto;
import com.it.helpdesk.server.service.TicketService;
import com.it.helpdesk.server.utils.AppConstant;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
public class TicketAuthentication {

    private final TicketService ticketService;

    @Value("${azure.client-id}")
    private String CLIENT_ID;

    public Ticket authenticateUserForTicketWithImage(Jwt jwt, TicketDto ticketDto) throws MessagingException, IOException {
        if (jwt != null) {
            String username = jwt.getClaim(AppConstant.USERNAME);
            String email = jwt.getClaim(AppConstant.EMAIL);
            Object audience = jwt.getClaim(AppConstant.AUDIENCE);
            List<String> roles = jwt.getClaim(AppConstant.ROLE);

            if (audience instanceof List && ((List<?>) audience).contains(CLIENT_ID)) {
                return ticketService.createTicketWithImage(username, email, ticketDto, roles);
            } else {
                throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
            }
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public Ticket authenticateUserForTicketWithoutImage(Jwt jwt, Ticket ticket) throws MessagingException, IOException {
        if (jwt != null) {
            String username = jwt.getClaim(AppConstant.USERNAME);
            String email = jwt.getClaim(AppConstant.EMAIL);
            Object audience = jwt.getClaim(AppConstant.AUDIENCE);
            List<String> roles = jwt.getClaim(AppConstant.ROLE);

            if (audience instanceof List && ((List<?>) audience).contains(CLIENT_ID)) {
                return ticketService.saveOneTicketWithoutImage(username, email, ticket, roles);
            } else {
                throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
            }
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }


    public List<Ticket> authenticateUserForFetchAllTickets(Jwt jwt) {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        Object audience = jwt.getClaim(AppConstant.AUDIENCE);
        String email1 = jwt.getClaim(AppConstant.EMAIL);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE) && roles.contains(AppConstant.TICKET_HR)) {
            return ticketService.fetchAllTickets();
        } else if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            return ticketService.fetchTicketsByCategoryOtherThanHR(email1);
        } else if (roles != null && roles.contains(AppConstant.TICKET_HR)) {
            return ticketService.fetchTicketByHrIssue(email1);
        } else if (roles == null && audience instanceof List && ((List<?>) audience).contains(CLIENT_ID)) {
            String email = jwt.getClaim(AppConstant.EMAIL);
            return ticketService.fetchTicketByEmail(email);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public Ticket authenticateUserForUpdateTicket(Jwt jwt, Ticket ticket, Long id) throws IOException, MessagingException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR)) {
            return ticketService.updateTicketById(ticket, id);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public DropdownValues authenticateUserForFetchDropdownValues(Jwt jwt) {
        Object audience = jwt.getClaim(AppConstant.AUDIENCE);
        if (audience instanceof List && ((List<?>) audience).contains(CLIENT_ID)) {
            List<String> priorities = Arrays.asList("high", "medium", "low");
            List<String> categories = Arrays.asList("hardware issue", "software issue", "hr related issue", "others");
            DropdownValues dropdownValuesDTO = new DropdownValues(priorities, categories);
            return dropdownValuesDTO;
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }
}

