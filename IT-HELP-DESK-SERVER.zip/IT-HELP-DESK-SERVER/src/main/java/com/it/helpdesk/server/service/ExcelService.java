package com.it.helpdesk.server.service;

import com.it.helpdesk.server.utils.ExcelResponse;
import org.springframework.security.oauth2.jwt.Jwt;

import java.io.IOException;

public interface ExcelService {

    ExcelResponse exportTicketsToExcel(Jwt jwt) throws IOException;

}
