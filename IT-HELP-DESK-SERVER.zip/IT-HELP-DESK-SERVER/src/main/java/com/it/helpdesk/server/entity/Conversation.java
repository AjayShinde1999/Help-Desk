package com.it.helpdesk.server.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "conversation")
public class Conversation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    @Column(length = 500)
    private String message;
    private String timestamp;
    private String ticketNo;
    private boolean readByUser;
    private boolean readByAdmin;
    private String ticketOwnerRole;
    @ManyToOne
    @JsonIgnore
    private Ticket ticket;

}
