package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Conversation;
import org.springframework.security.oauth2.jwt.Jwt;

import java.nio.file.AccessDeniedException;
import java.util.List;

public interface ConversationService {

    Conversation saveConversation(Jwt jwt, Conversation conversation, long ticketId) throws AccessDeniedException;

    List<Conversation> fetchUsersMessagesForAdmin(long ticketId,List<String> roles);

    List<Conversation> fetchAdminMessagesForUser(long ticketId);
}
