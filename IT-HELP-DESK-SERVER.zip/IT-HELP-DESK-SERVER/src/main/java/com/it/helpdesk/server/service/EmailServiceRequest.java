package com.it.helpdesk.server.service;

import com.it.helpdesk.server.payload.ServiceRequestDto;

import javax.mail.MessagingException;

public interface EmailServiceRequest {

    void sendEmailForServiceRequest(ServiceRequestDto serviceRequestDto) throws MessagingException;
}
