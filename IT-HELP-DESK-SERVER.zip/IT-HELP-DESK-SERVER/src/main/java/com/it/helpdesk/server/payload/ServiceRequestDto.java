package com.it.helpdesk.server.payload;

import lombok.Data;

@Data
public class ServiceRequestDto {

    private String subject;
    private String message;
    private String startDate;
    private String startTime;
    private String endDate;
    private String endTime;

}
