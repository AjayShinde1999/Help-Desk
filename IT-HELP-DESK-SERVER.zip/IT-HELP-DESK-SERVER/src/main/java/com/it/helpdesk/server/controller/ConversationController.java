package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.security.ConversationAuthentication;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.nio.file.AccessDeniedException;
import java.util.List;

@RestController
@RequestMapping("/api/tickets")
public class ConversationController {

    private ConversationAuthentication conversationAuthentication;

    public ConversationController(ConversationAuthentication conversationAuthentication) {
        this.conversationAuthentication = conversationAuthentication;
    }

    @PostMapping("/{ticketId}/conversation")
    @ResponseStatus(HttpStatus.CREATED)
    public Conversation saveConversation(@AuthenticationPrincipal Jwt jwt, @RequestBody Conversation conversation, @PathVariable long ticketId) throws AccessDeniedException {
        return conversationAuthentication.authenticateUsersForSendConversation(jwt, conversation, ticketId);
    }

    @GetMapping("/{ticketId}/conversation")
    @ResponseStatus(HttpStatus.OK)
    public List<Conversation> fetchAllConversationByTicketId(@AuthenticationPrincipal Jwt jwt, @PathVariable long ticketId) throws AccessDeniedException {
        return conversationAuthentication.authenticateUsersForFetchAllConversation(jwt, ticketId);
    }
}
