package com.it.helpdesk.server.security;

import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.payload.InventoryDto;
import com.it.helpdesk.server.service.InventoryService;
import com.it.helpdesk.server.utils.AppConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.List;

@Component
public class InventoryAuthentication {

    @Autowired
    private InventoryService inventoryService;

    public Inventory authenticateAdminForSaveInventoryWithAttachment(Jwt jwt, InventoryDto inventoryDto) throws IOException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            return inventoryService.saveOneInventory(inventoryDto);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public Inventory authenticateAdminForSaveInventoryWithOutAttachment(Jwt jwt, Inventory inventory) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            return inventoryService.saveOneInventoryWithoutAttachment(inventory);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public List<Inventory> authenticateAdminForFetchAllInventory(Jwt jwt) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            return inventoryService.fetchAllInventory();
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public Inventory authenticateAdminForUpdateInventoryWithOutAttachment(Jwt jwt, Inventory inventory, long id) throws IOException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            return inventoryService.updateInventory(inventory, id);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public Inventory authenticateAdminForUpdateInventoryWithAttachment(Jwt jwt, InventoryDto inventoryDto, long id) throws IOException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            return inventoryService.updateInventoryWithImage(inventoryDto, id);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }
}
