package com.it.helpdesk.server.security;

import com.it.helpdesk.server.payload.ServiceRequestDto;
import com.it.helpdesk.server.service.EmailServiceRequest;
import com.it.helpdesk.server.utils.ApiResponse;
import com.it.helpdesk.server.utils.AppConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import java.util.List;

@Component
public class ServiceRequestAuthentication {

    @Autowired
    private EmailServiceRequest emailServiceRequest;

    public ApiResponse authenticateAdminForSendServiceRequestMail(Jwt jwt, ServiceRequestDto serviceRequestDto) throws MessagingException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null && roles.contains(AppConstant.TICKET_WRITE)) {
            emailServiceRequest.sendEmailForServiceRequest(serviceRequestDto);
            ApiResponse response = new ApiResponse();
            response.setMessage("SENT!!!!!");
            return response;
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }
}
