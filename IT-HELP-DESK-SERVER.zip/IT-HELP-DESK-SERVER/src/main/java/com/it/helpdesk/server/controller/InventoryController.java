package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.payload.InventoryDto;
import com.it.helpdesk.server.security.InventoryAuthentication;
import com.it.helpdesk.server.service.InventoryExcelService;
import com.it.helpdesk.server.utils.ExcelResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    private InventoryAuthentication inventoryAuthentication;

    private InventoryExcelService inventoryExcelService;

    public InventoryController(InventoryAuthentication inventoryAuthentication, InventoryExcelService inventoryExcelService) {
        this.inventoryAuthentication = inventoryAuthentication;
        this.inventoryExcelService = inventoryExcelService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Inventory saveInventoryWithAttachment(@AuthenticationPrincipal Jwt jwt, InventoryDto inventoryDto) throws IOException {
        return inventoryAuthentication.authenticateAdminForSaveInventoryWithAttachment(jwt, inventoryDto);
    }

    @PostMapping("/no-img")
    @ResponseStatus(HttpStatus.CREATED)
    public Inventory saveInventoryWithOutAttachment(@AuthenticationPrincipal Jwt jwt, Inventory inventory) throws IOException {
        return inventoryAuthentication.authenticateAdminForSaveInventoryWithOutAttachment(jwt, inventory);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Inventory> fetchAllInventory(@AuthenticationPrincipal Jwt jwt) throws AccessDeniedException {
        return inventoryAuthentication.authenticateAdminForFetchAllInventory(jwt);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Inventory updateInventoryWithOutAttachment(@AuthenticationPrincipal Jwt jwt, @RequestBody Inventory inventory, @PathVariable long id) throws IOException {
        return inventoryAuthentication.authenticateAdminForUpdateInventoryWithOutAttachment(jwt, inventory, id);
    }

    @PutMapping("/new-file/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Inventory updateInventoryWithAttachment(@AuthenticationPrincipal Jwt jwt, InventoryDto inventoryDto, @PathVariable long id) throws IOException {
        return inventoryAuthentication.authenticateAdminForUpdateInventoryWithAttachment(jwt, inventoryDto, id);
    }

    @GetMapping("/download-archive")
    @ResponseStatus(HttpStatus.OK)
    public ExcelResponse downloadArchive(@AuthenticationPrincipal Jwt jwt) throws IOException {
        return inventoryExcelService.exportInventoryToExcel();
    }
}
