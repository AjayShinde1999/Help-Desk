package com.it.helpdesk.server.repository;

import com.it.helpdesk.server.entity.Conversation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConversationRepository extends JpaRepository<Conversation, Long> {

    List<Conversation> findByTicketId(long ticketId);

    List<Conversation> findByTicketIdAndReadByAdminIsFalse(long ticketId);

    List<Conversation> findByTicketIdAndReadByUserIsFalse(Long ticketId);

}
