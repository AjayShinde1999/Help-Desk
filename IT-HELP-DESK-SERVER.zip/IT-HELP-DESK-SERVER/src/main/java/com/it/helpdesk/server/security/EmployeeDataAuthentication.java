package com.it.helpdesk.server.security;

import com.it.helpdesk.server.entity.EmployeeData;
import com.it.helpdesk.server.service.EmployeeDataService;
import com.it.helpdesk.server.utils.ApiResponse;
import com.it.helpdesk.server.utils.AppConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.jwt.Jwt;

import java.nio.file.AccessDeniedException;
import java.util.List;

@Configuration
public class EmployeeDataAuthentication {

    @Autowired
    private EmployeeDataService employeeDataService;

    public EmployeeData authenticateAdminToSaveEmployeeData(Jwt jwt, EmployeeData employeeData) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);

        if (roles != null && (roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR))) {
            return employeeDataService.saveOneEmployee(employeeData);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public EmployeeData authenticateAdminOrUserToFetchEmployeeData(Jwt jwt) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        String email = jwt.getClaim(AppConstant.EMAIL);

        if (roles == null || roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR)) {
            return employeeDataService.getEmployeeDataByEmail(email);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public EmployeeData authenticateAdminOrUserToUpdateEmployeeData(Jwt jwt, EmployeeData employeeData, long id) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);

        if (roles != null && (roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR))) {
            return employeeDataService.updateEmployeeData(employeeData, id);
        } else if (roles == null) {
            return employeeDataService.updateEmployeeDataOnlySkills(employeeData, id);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public ApiResponse authenticateAdminToDeleteEmployeeData(Jwt jwt, long id) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);

        if (roles != null && (roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR))) {
            return employeeDataService.deleteOneEmployeeDataByEmail(id);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public Object authenticateAdminOrUserToSearchEmployeeData(Jwt jwt, String q) throws AccessDeniedException, InterruptedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        String email = jwt.getClaim(AppConstant.EMAIL);

        if (roles != null && (roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR))) {
            return employeeDataService.searchEmployeeDataForAdmin(q);
        } else if (roles == null) {
            return employeeDataService.searchEmployeeDataForUser(email,q);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }
}
