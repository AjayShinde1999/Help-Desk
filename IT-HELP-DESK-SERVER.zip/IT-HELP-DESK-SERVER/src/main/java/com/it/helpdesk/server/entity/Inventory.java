package com.it.helpdesk.server.entity;


import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "inventory")
public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String employeeName;
    private String employeeId;
    private String make;
    private String model;
    private String processor;
    private String ramSize;
    private String storageSize;
    private String serialNo;
    private String assetTagId;
    private String warranty;
    private String agreement;
    private String attachment;
    private boolean assigned;
    @Column(length = 500)
    private String additionalDetails;
    private String lastUpdatedDate;
    private String expectedReturnDate;
    private String deviceType;

}
