package com.it.helpdesk.server.service;

import com.it.helpdesk.server.utils.ExcelResponse;

import java.io.IOException;

public interface InventoryExcelService {

    ExcelResponse exportInventoryToExcel() throws IOException;
}
