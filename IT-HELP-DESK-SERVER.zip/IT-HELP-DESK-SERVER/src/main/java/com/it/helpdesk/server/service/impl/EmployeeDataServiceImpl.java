package com.it.helpdesk.server.service.impl;

import com.it.helpdesk.server.entity.EmployeeData;
import com.it.helpdesk.server.payload.EmployeeDataDto;
import com.it.helpdesk.server.repository.EmployeeDataRepository;
import com.it.helpdesk.server.service.EmployeeDataService;
import com.it.helpdesk.server.utils.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class EmployeeDataServiceImpl implements EmployeeDataService {

    @Autowired
    private EmployeeDataRepository employeeDataRepository;

    @Override
    public EmployeeData saveOneEmployee(EmployeeData employeeData) {

        if (employeeDataRepository.existsByEmployeeId(employeeData.getEmployeeId())) {
            throw new IllegalArgumentException("employee id already exist");
        }
        if (employeeDataRepository.existsByEmail(employeeData.getEmail())) {
            throw new IllegalArgumentException("email already exist");
        }
        if (employeeDataRepository.existsByMobileNumber(employeeData.getMobileNumber())) {
            throw new IllegalArgumentException("mobile number already exist");
        }
        return employeeDataRepository.save(employeeData);
    }

    @Override
    public EmployeeData getEmployeeDataByEmail(String email) {
        return employeeDataRepository.findByEmail(email);
    }

    @Override
    public EmployeeData updateEmployeeData(EmployeeData employeeData, long id) {
        EmployeeData existingEmployeeData = employeeDataRepository.findById(id).orElseThrow(
                () -> new NoSuchElementException("Employee Not Found With ID : " + id)
        );

        EmployeeData existingEmployeeWithEmail = employeeDataRepository.findByEmail(employeeData.getEmail());
        EmployeeData existingEmployeeWithEmployeeId = employeeDataRepository.findByEmployeeId(employeeData.getEmployeeId());
        EmployeeData existingEmployeeWithMobileNumber = employeeDataRepository.findByMobileNumber(employeeData.getMobileNumber());

        if (existingEmployeeWithEmail != null && existingEmployeeWithEmail.getId() != id) {
            throw new IllegalArgumentException("email already exist");
        }

        if (existingEmployeeWithEmployeeId != null && existingEmployeeWithEmployeeId.getId() != id) {
            throw new IllegalArgumentException("employee id already exist");
        }

        if (existingEmployeeWithMobileNumber != null && existingEmployeeWithMobileNumber.getId() != id) {
            throw new IllegalArgumentException("mobile number already exist");
        }

        existingEmployeeData.setEmployeeId(employeeData.getEmployeeId());
        existingEmployeeData.setName(employeeData.getName());
        existingEmployeeData.setMobileNumber(employeeData.getMobileNumber());
        existingEmployeeData.setEmail(employeeData.getEmail());
        existingEmployeeData.setProject(employeeData.getProject());
        existingEmployeeData.setReportingManager(employeeData.getReportingManager());
        existingEmployeeData.setDesignation(employeeData.getDesignation());
        existingEmployeeData.setExperience(employeeData.getExperience());
        existingEmployeeData.setSkills(employeeData.getSkills());
        return employeeDataRepository.save(existingEmployeeData);
    }

    @Override
    public EmployeeData updateEmployeeDataOnlySkills(EmployeeData employeeData, long id) {
        EmployeeData existingEmployeeData = employeeDataRepository.findById(id).orElseThrow(
                () -> new NoSuchElementException("Employee Not Found With ID : " + id)
        );
        existingEmployeeData.setSkills(employeeData.getSkills());
        return employeeDataRepository.save(existingEmployeeData);
    }

    @Override
    public List<EmployeeData> saveListOfEmployees(List<EmployeeData> employeeData) {
        return employeeDataRepository.saveAll(employeeData);
    }

    @Override
    public List<EmployeeData> getAllEmployees() {
        return employeeDataRepository.findAll();
    }

    @Override
    public ApiResponse deleteOneEmployeeDataByEmail(long id) {
        employeeDataRepository.deleteById(id);
        ApiResponse response = new ApiResponse();
        response.setMessage("Deleted Successfully");
        return response;
    }

    public List<EmployeeData> searchEmployeeDataForAdmin(String q) throws InterruptedException {
        return employeeDataRepository.findBySearchCriteria(q);
    }

    public List<Object> searchEmployeeDataForUser(String email, String q) {
        List<EmployeeData> employeeDataList = employeeDataRepository.findBySearchCriteria(q);
        List<Object> employeeDetails = new ArrayList<>();

        for (EmployeeData employeeData : employeeDataList) {

            if (email.equals(employeeData.getEmail())) {
                EmployeeData employee = new EmployeeData();
                employee.setId(employeeData.getId());
                employee.setEmployeeId(employeeData.getEmployeeId());
                employee.setName(employeeData.getName());
                employee.setEmail(employeeData.getEmail());
                employee.setDesignation(employeeData.getDesignation());
                employee.setReportingManager(employeeData.getReportingManager());
                employee.setExperience(employeeData.getExperience());
                employee.setProject(employeeData.getProject());
                employee.setSkills(employeeData.getSkills());
                employee.setMobileNumber(employeeData.getMobileNumber());
                employeeDetails.add(employee);
            }

            if (!email.equals(employeeData.getEmail())) {
                EmployeeDataDto employeeDataDto = new EmployeeDataDto();
                employeeDataDto.setEmployeeId(employeeData.getEmployeeId());
                employeeDataDto.setName(employeeData.getName());
                employeeDataDto.setEmail(employeeData.getEmail());
                employeeDataDto.setDesignation(employeeData.getDesignation());
                employeeDataDto.setExperience(employeeData.getExperience());
                employeeDetails.add(employeeDataDto);
            }
        }
        return employeeDetails;


//        for (EmployeeData employeeData : employeeDataList) {
//            EmployeeDataDto employeeDataDto = new EmployeeDataDto();
//            employeeDataDto.setEmployeeId(employeeData.getEmployeeId());
//            employeeDataDto.setName(employeeData.getName());
//            employeeDataDto.setEmail(employeeData.getEmail());
//            employeeDataDto.setDesignation(employeeData.getDesignation());
//            employeeDataDto.setExperience(employeeData.getExperience());
//            employeeDetails.add(employeeDataDto);
//        }
//        return employeeDetails;
    }
}
