package com.it.helpdesk.server.exception;

import com.it.helpdesk.server.utils.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.util.NoSuchElementException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiResponse handleNoSuchElementException(NoSuchElementException exception) {
        ApiResponse response = new ApiResponse();
        response.setMessage(exception.getMessage());
        return response;
    }

    @ExceptionHandler(IllegalStateException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ApiResponse handleIllegalStateException(IllegalStateException exception) {
        ApiResponse response = new ApiResponse();
        response.setMessage(exception.getMessage());
        return response;
    }
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ApiResponse handleIllegalArgumentException(IllegalArgumentException exception) {
        ApiResponse response = new ApiResponse();
        response.setMessage(exception.getMessage());
        return response;
    }

    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ApiResponse handleAccessDeniedException(AccessDeniedException exception) {
        ApiResponse response = new ApiResponse();
        response.setMessage(exception.getMessage());
        return response;
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    @ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
    public ApiResponse handleMaxSizeException(MaxUploadSizeExceededException exception) {
        ApiResponse response = new ApiResponse();
        response.setMessage(exception.getMessage());
        return response;
    }
}
