package com.it.helpdesk.server.service.impl;

import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.repository.ConversationRepository;
import com.it.helpdesk.server.repository.TicketRepository;
import com.it.helpdesk.server.service.ConversationService;
import com.it.helpdesk.server.utils.AppConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.nio.file.AccessDeniedException;
import java.util.List;

@Service
@Slf4j
public class ConversationServiceImpl implements ConversationService {

    private ConversationRepository conversationRepository;

    private TicketRepository ticketRepository;

    public ConversationServiceImpl(ConversationRepository conversationRepository, TicketRepository ticketRepository) {
        this.conversationRepository = conversationRepository;
        this.ticketRepository = ticketRepository;
    }

    @Value("${azure.client-id}")
    private String client_ID;

    @Override
    public Conversation saveConversation(Jwt jwt, Conversation conversation, long ticketId) throws AccessDeniedException {
        Conversation updatedConversation = setReadBasedOnUserRole(jwt, conversation, ticketId);
        return conversationRepository.save(updatedConversation);
    }

    private Conversation setReadBasedOnUserRole(Jwt jwt, Conversation conversations, long ticketId) throws AccessDeniedException {
        Ticket ticket = ticketRepository.findById(ticketId).get();
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        String name = jwt.getClaim(AppConstant.USERNAME);
        String email = jwt.getClaim(AppConstant.EMAIL);
        Conversation conversation = new Conversation();
        conversation.setTicket(ticket);
        conversation.setName(name);
        conversation.setEmail(email);
        conversation.setTicketNo(ticket.getTicketNo());
        conversation.setMessage(conversations.getMessage());
        conversation.setTimestamp(conversations.getTimestamp());
        conversation.setTicketOwnerRole(ticket.getTicketOwnerRole());

        if (roles == null && conversation.getTicketOwnerRole().equals("user")) {
            conversation.setReadByUser(true);
            conversation.setReadByAdmin(false);
            log.info("User");
        } else if ((roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR)) && conversation.getTicketOwnerRole().equals("user")) {
            conversation.setReadByUser(false);
            conversation.setReadByAdmin(true);
            log.info("User 2");
        } else if ((roles.contains(AppConstant.TICKET_WRITE) && conversation.getTicketOwnerRole().equals("admin")) || (roles.contains("ticket.hr") && conversation.getTicketOwnerRole().equals("hr"))) {
            conversation.setReadByUser(true);
            conversation.setReadByAdmin(false);
            log.info("Admin to HR");
        } else if ((roles.contains(AppConstant.TICKET_WRITE) && conversation.getTicketOwnerRole().equals("hr")) || (roles.contains(AppConstant.TICKET_HR) && conversation.getTicketOwnerRole().equals("admin"))) {
            conversation.setReadByUser(false);
            conversation.setReadByAdmin(true);
            log.info("Else Condition");
        }
        return conversation;
    }

    @Override
    public List<Conversation> fetchUsersMessagesForAdmin(long ticketId,List<String> roles) {
        List<Conversation> conversations = conversationRepository.findByTicketId(ticketId);
        for (Conversation conversation : conversations) {
            if((conversation.getTicketOwnerRole().equals("admin") && roles.contains(AppConstant.TICKET_WRITE)) || (conversation.getTicketOwnerRole().equals("hr") && roles.contains("ticket.hr")) ) {
                conversation.setReadByUser(true);
                log.info("If condition Fetch");
            } else {
                conversation.setReadByAdmin(true);
                log.info("Else If condition Fetch");
            }
        }
        conversationRepository.saveAll(conversations);
        return conversations;
    }

    @Override
    public List<Conversation> fetchAdminMessagesForUser(long ticketId) {
        List<Conversation> conversations = conversationRepository.findByTicketId(ticketId);
        for (Conversation conversation : conversations) {
            conversation.setReadByUser(true);
        }
        conversationRepository.saveAll(conversations);
        return conversations;
    }
}
