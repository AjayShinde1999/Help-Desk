package com.it.helpdesk.server.repository;

import com.it.helpdesk.server.entity.EmployeeData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeDataRepository extends JpaRepository<EmployeeData, Long> {

    EmployeeData findByEmail(String email);

    EmployeeData findByEmployeeId(String employeeId);

    EmployeeData findByMobileNumber(String mobileNumber);

    boolean existsByEmployeeId(String employeeNo);

    boolean existsByEmail(String email);

    boolean existsByMobileNumber(String mobileNo);

    List<EmployeeData> findByEmployeeIdContainingIgnoreCaseOrNameContainingIgnoreCaseOrEmailContainingIgnoreCaseOrDesignationContainingIgnoreCaseOrSkillsContainingIgnoreCase(String q, String q1, String q2, String q3, String q4);

    @Query("SELECT e FROM EmployeeData e WHERE " +
            "LOWER(e.employeeId) = LOWER(:q) " +
            "OR LOWER(e.name) LIKE LOWER(concat(:q, '%')) " +  // Match at the beginning of any word or the name
            "OR LOWER(e.name) LIKE LOWER(concat('% ', :q, '%')) " +   // Match as a separate word
            "OR LOWER(e.email) LIKE LOWER(concat(:q, '%')) " +  // Match at the beginning of any word or the email
            "OR LOWER(e.email) LIKE LOWER(concat('% ', :q, '%')) " +  // Match as a separate word
            "OR LOWER(e.designation) LIKE LOWER(concat(:q, '%')) " +  // Match at the beginning of any word or the designation
            "OR LOWER(e.designation) LIKE LOWER(concat('% ', :q, '%')) " +  // Match as a separate word
            "OR LOWER(e.skills) LIKE LOWER(concat(:q, '%')) " +  // Match at the beginning of any word or the skill
            "OR LOWER(e.skills) LIKE LOWER(concat('% ', :q, '%'))")  // Match as a separate word
    List<EmployeeData> findBySearchCriteria(@Param("q") String q);
}


