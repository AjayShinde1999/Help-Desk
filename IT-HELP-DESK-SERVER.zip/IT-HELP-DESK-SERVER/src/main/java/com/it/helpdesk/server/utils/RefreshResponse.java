package com.it.helpdesk.server.utils;

import lombok.Data;

@Data
public class RefreshResponse {

    private String status;
}
