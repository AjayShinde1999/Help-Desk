package com.it.helpdesk.server.service.impl;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobServiceClient;
import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.TicketDto;
import com.it.helpdesk.server.repository.ConversationRepository;
import com.it.helpdesk.server.repository.TicketRepository;
import com.it.helpdesk.server.service.EmailService;
import com.it.helpdesk.server.service.TicketService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.mail.MessagingException;
import java.time.LocalDate;
import java.util.*;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class TicketServiceImpl implements TicketService {

    private final TicketRepository ticketRepository;
    private final BlobServiceClient blobServiceClient;
    private final EmailService emailService;
    private final ConversationRepository conversationRepository;


    @Value("${azure.blob.containerName}")
    private String blobContainerName;

    @Override
    public Ticket createTicketWithImage(String username, String email, TicketDto ticketDto, List<String> roles) throws IOException, MessagingException {
        String imageUrl = null;

        if (ticketDto.getImageUrl() != null && !ticketDto.getImageUrl().isEmpty()) {
            BlobClient blobClient = blobServiceClient.getBlobContainerClient(blobContainerName).getBlobClient(ticketDto.getImageUrl().getOriginalFilename());
            blobClient.upload(ticketDto.getImageUrl().getInputStream(), ticketDto.getImageUrl().getSize(), true);
            imageUrl = blobClient.getBlobUrl();
        }

        if (ticketDto.getDate().equals(LocalDate.now().toString())) {
            Ticket ticket = new Ticket();
            ticket.setUsername(username);
            ticket.setEmail(email);
            ticket.setSubject(ticketDto.getSubject());
            ticket.setDate(ticketDto.getDate());
            ticket.setPriority(ticketDto.getPriority());
            ticket.setCategory(ticketDto.getCategory());
            ticket.setStatus(ticketDto.getStatus());
            ticket.setDescription(ticketDto.getDescription());
            ticket.setImageUrl(imageUrl);
            ticket.setComments(ticketDto.getComments());
            ticket.setTicketCloseDate(ticketDto.getTicketCloseDate());
            ticket.setModifiedBy(ticketDto.getModifiedBy());

            if (roles == null) {
                ticket.setTicketOwnerRole("user");
            } else if (roles.contains("ticket.write")) {
                ticket.setTicketOwnerRole("admin");
            } else if (roles.contains("ticket.hr")) {
                ticket.setTicketOwnerRole("hr");
            }

            Ticket newTicket = ticketRepository.save(ticket);
            Ticket ticket2 = ticketRepository.findById(newTicket.getId()).get();
            String generatedNo = generateNextSequentialTicketNumber(newTicket.getId());
            ticket2.setTicketNo(generatedNo);
            Ticket saveTicket = ticketRepository.save(ticket2);
            CompletableFuture.runAsync(() -> {
                try {
                    emailService.createTicketEmail(saveTicket);
                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            });
            return saveTicket;
//            emailService.createTicketEmail(saveTicket);
//            return saveTicket;
        } else {
            throw new IllegalArgumentException("Invalid Date");
        }
    }

    @Override
    public Ticket saveOneTicketWithoutImage(String username, String email, Ticket ticket, List<String> roles) throws MessagingException {

        if (ticket.getDate().equals(LocalDate.now().toString())) {
            Ticket ticket1 = new Ticket();
            ticket1.setUsername(username);
            ticket1.setEmail(email);
            ticket1.setSubject(ticket.getSubject());
            ticket1.setDate(ticket.getDate());
            ticket1.setPriority(ticket.getPriority());
            ticket1.setCategory(ticket.getCategory());
            ticket1.setStatus(ticket.getStatus());
            ticket1.setDescription(ticket.getDescription());
            ticket1.setImageUrl(ticket.getImageUrl());
            ticket1.setComments(ticket.getComments());
            ticket1.setTicketCloseDate(ticket.getTicketCloseDate());
            ticket1.setModifiedBy(ticket.getModifiedBy());
            if (roles == null) {
                ticket1.setTicketOwnerRole("user");
            } else if (roles.contains("ticket.write")) {
                ticket1.setTicketOwnerRole("admin");
            } else if (roles.contains("ticket.hr")) {
                ticket1.setTicketOwnerRole("hr");
            }
            Ticket newTicket = ticketRepository.save(ticket1);
            Ticket ticket2 = ticketRepository.findById(newTicket.getId()).get();
            String generatedNo = generateNextSequentialTicketNumber(newTicket.getId());
            ticket2.setTicketNo(generatedNo);
            Ticket saveTicket = ticketRepository.save(ticket2);
            CompletableFuture.runAsync(() -> {
                try {
                    emailService.createTicketEmail(saveTicket);
                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            });
            return saveTicket;
//            emailService.createTicketEmail(saveTicket);
//            return saveTicket;
        } else {
            throw new IllegalArgumentException("Invalid Date");
        }
    }


    @Transactional
    private String generateNextSequentialTicketNumber(Long id) {
        String ticketFormat = "3KTHD-%02d";
        return String.format(ticketFormat, id);
    }

    @Override
    public List<Ticket> fetchTicketByHrIssue(String email) {
        List<Ticket> tickets = ticketRepository.findAll();
        List<Ticket> collect1 = tickets.stream().filter(ticket -> "hr related issue".equals(ticket.getCategory()) && (ticket.getStatus().equals("open") || ticket.getStatus().equals("progress"))).collect(Collectors.toList());
        List<Ticket> collect2 = tickets.stream().filter(ticket -> email.equals(ticket.getEmail()) && !"hr related issue".equals(ticket.getCategory())).collect(Collectors.toList());
        List<Ticket> collect3 = tickets.stream().filter(ticket -> email.equals(ticket.getEmail()) && ticket.getCategory().equals("hr related issue") && (ticket.getStatus().equals("resolved") || ticket.getStatus().equals("rejected"))).collect(Collectors.toList());

        collect1.addAll(collect2);
        collect1.addAll(collect3);
        for (Ticket ticket : collect1) {
            List<Conversation> conversations;
            if (ticket.getTicketOwnerRole().equals("hr")) {
                conversations = conversationRepository.findByTicketIdAndReadByUserIsFalse(ticket.getId());
            } else {
                conversations = conversationRepository.findByTicketIdAndReadByAdminIsFalse(ticket.getId());
            }
            int unreadCount = conversations.size();
            ticket.setUnreadMsgCount(unreadCount);
        }
        return collect1;
    }

    @Override
    public List<Ticket> fetchTicketsByCategoryOtherThanHR(String email) {
        List<Ticket> tickets = ticketRepository.findAll();
        List<Ticket> collect1 = tickets.stream().filter(ticket -> !"hr related issue".equals(ticket.getCategory()) && ticket.getStatus().equals("open") || ticket.getStatus().equals("progress")).collect(Collectors.toList());
        List<Ticket> collect2 = tickets.stream().filter(ticket -> email.equals(ticket.getEmail()) && "hr related issue".equals(ticket.getCategory())).collect(Collectors.toList());
        List<Ticket> collect3 = tickets.stream().filter(ticket -> email.equals(ticket.getEmail()) && !ticket.getCategory().equals("hr related issue") && (ticket.getStatus().equals("resolved") || ticket.getStatus().equals("rejected"))).collect(Collectors.toList());

        collect1.addAll(collect2);
        collect1.addAll(collect3);
        for (Ticket ticket : collect1) {
            List<Conversation> conversations;
            if (ticket.getTicketOwnerRole().equals("admin")) {
                conversations = conversationRepository.findByTicketIdAndReadByUserIsFalse(ticket.getId());
            } else {
                conversations = conversationRepository.findByTicketIdAndReadByAdminIsFalse(ticket.getId());
            }
            int unreadCount = conversations.size();
            ticket.setUnreadMsgCount(unreadCount);
        }
        return collect1;
    }

    @Override
    public List<Ticket> fetchTicketByEmail(String email) {
        List<Ticket> tickets = ticketRepository.findByEmail(email);
        for (Ticket ticket : tickets) {
            List<Conversation> conversations = conversationRepository.findByTicketIdAndReadByUserIsFalse(ticket.getId());
            int unreadCount = conversations.size();
            ticket.setUnreadMsgCount(unreadCount);
        }
        return tickets;
    }

    @Override
    public List<Ticket> fetchAllTickets() {
        List<Ticket> tickets = ticketRepository.findAll();
        List<Ticket> collect = tickets.stream().filter(ticket -> ticket.getStatus().equals("open") || ticket.getStatus().equals("progress")).collect(Collectors.toList());
        for (Ticket ticket : collect) {
            List<Conversation> conversations = conversationRepository.findByTicketIdAndReadByAdminIsFalse(ticket.getId());
            int unreadCount = conversations.size();
            ticket.setUnreadMsgCount(unreadCount);
        }
        return collect;
    }

//    void unreadMsgCount(List<Ticket> tickets) {
//        for (Ticket ticket : tickets) {
//            List<Conversation> conversations = conversationRepository.findByTicketIdAndReadByAdminIsFalse(ticket.getId());
//            int unreadCount = conversations.size();
//            ticket.setUnreadMsgCount(unreadCount);
//        }
//    }

    @Override
    public Ticket updateTicketById(Ticket updatedTicket, long id) throws MessagingException {
        Optional<Ticket> optionalTicket = ticketRepository.findById(id);
        if (optionalTicket.isPresent()) {
            Ticket existingTicket = optionalTicket.get();
            String currentStatus = existingTicket.getStatus();
            String updatedStatus = updatedTicket.getStatus();

            if (currentStatus.equals("open") && !updatedStatus.equals("progress") && !updatedStatus.equals("rejected")) {
                throw new IllegalArgumentException("Invalid status transition: OPEN ticket can only move to PROGRESS or REJECTED.");
            } else if (currentStatus.equals("progress") && !updatedStatus.equals("resolved")) {
                throw new IllegalArgumentException("Invalid status transition: PROGRESS ticket can only move to RESOLVED.");
            } else if (currentStatus.equals("resolved") || currentStatus.equals("rejected")) {
                throw new IllegalArgumentException("Ticket with status RESOLVED or REJECTED cannot be updated.");
            }

            if (!Objects.equals(existingTicket.getTicketNo(), updatedTicket.getTicketNo())
                    || !Objects.equals(existingTicket.getUsername(), updatedTicket.getUsername())
                    || !Objects.equals(existingTicket.getEmail(), updatedTicket.getEmail())
                    || !Objects.equals(existingTicket.getSubject(), updatedTicket.getSubject())
                    || !Objects.equals(existingTicket.getDate(), updatedTicket.getDate())
                    || !Objects.equals(existingTicket.getPriority(), updatedTicket.getPriority())
                    || !Objects.equals(existingTicket.getCategory(), updatedTicket.getCategory())
                    || !Objects.equals(existingTicket.getDescription(), updatedTicket.getDescription())
                    || !Objects.equals(existingTicket.getImageUrl(), updatedTicket.getImageUrl())) {
                throw new IllegalArgumentException("Fields other than status and comments cannot be updated.");
            }
            existingTicket.setStatus(updatedTicket.getStatus());
            existingTicket.setComments(updatedTicket.getComments());
            existingTicket.setTicketCloseDate(updatedTicket.getTicketCloseDate());
            existingTicket.setModifiedBy(updatedTicket.getModifiedBy());
            Ticket updateTicket = ticketRepository.save(existingTicket);
            CompletableFuture<Void> emailTrigger = CompletableFuture.runAsync(() -> {
                try {
                    emailService.updateTicketEmail(updateTicket);
                } catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            });
            return updateTicket;
        } else {
            throw new NoSuchElementException("Ticket with ID " + id + " not found");
        }
    }

    @Scheduled(fixedRate = 3600000)
    public void runningHourly() {
        log.info("Running");
    }
}
