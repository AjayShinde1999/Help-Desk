package com.it.helpdesk.server.service.impl;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobServiceClient;
import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.payload.InventoryDto;
import com.it.helpdesk.server.repository.InventoryRepository;
import com.it.helpdesk.server.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class InventoryServiceImpl implements InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;
    @Autowired
    private BlobServiceClient blobServiceClient;
    @Value("${azure.blob.containerName}")
    private String blobContainerName;

    @Override
    public Inventory saveOneInventory(InventoryDto inventoryDto) throws IOException {

        if (inventoryRepository.existsBySerialNo(inventoryDto.getSerialNo())) {
            throw new IllegalArgumentException("serial number already exist");
        }

        if (inventoryRepository.existsByAssetTagId(inventoryDto.getAssetTagId())) {
            throw new IllegalArgumentException("asset tag id already exist");
        }

        String attachment = null;
        if (inventoryDto.getAttachment() != null && !inventoryDto.getAttachment().isEmpty()) {
            BlobClient blobClient = blobServiceClient.getBlobContainerClient(blobContainerName).getBlobClient(inventoryDto.getAttachment().getOriginalFilename());
            blobClient.upload(inventoryDto.getAttachment().getInputStream(), inventoryDto.getAttachment().getSize(), true);
            attachment = blobClient.getBlobUrl();
        }

        Inventory inventory = new Inventory();
        inventory.setEmployeeName(inventoryDto.getEmployeeName());
        inventory.setEmployeeId(inventoryDto.getEmployeeId());
        inventory.setMake(inventoryDto.getMake());
        inventory.setModel(inventoryDto.getModel());
        inventory.setProcessor(inventoryDto.getProcessor());
        inventory.setRamSize(inventoryDto.getRamSize());
        inventory.setStorageSize(inventoryDto.getStorageSize());
        inventory.setSerialNo(inventoryDto.getSerialNo());
        inventory.setAssetTagId(inventoryDto.getAssetTagId());
        inventory.setWarranty(inventoryDto.getWarranty());
        inventory.setAgreement(inventoryDto.getAgreement());
        inventory.setAttachment(attachment);
        inventory.setAssigned(inventoryDto.isAssigned());
        inventory.setAdditionalDetails(inventoryDto.getAdditionalDetails());
        inventory.setLastUpdatedDate(inventoryDto.getLastUpdatedDate());
        inventory.setExpectedReturnDate(inventoryDto.getExpectedReturnDate());
        inventory.setDeviceType(inventoryDto.getDeviceType());
        return inventoryRepository.save(inventory);
    }

    @Override
    public Inventory saveOneInventoryWithoutAttachment(Inventory inventory) {

        if (inventoryRepository.existsBySerialNo(inventory.getSerialNo())) {
            throw new IllegalArgumentException("serial number already exist");
        }

        if (inventoryRepository.existsByAssetTagId(inventory.getAssetTagId())) {
            throw new IllegalArgumentException("asset tag id already exist");
        }


        Inventory inventory1 = new Inventory();
        inventory1.setEmployeeName(inventory.getEmployeeName());
        inventory1.setEmployeeId(inventory.getEmployeeId());
        inventory1.setMake(inventory.getMake());
        inventory1.setModel(inventory.getModel());
        inventory1.setProcessor(inventory.getProcessor());
        inventory1.setRamSize(inventory.getRamSize());
        inventory1.setStorageSize(inventory.getStorageSize());
        inventory1.setSerialNo(inventory.getSerialNo());
        inventory1.setAssetTagId(inventory.getAssetTagId());
        inventory1.setWarranty(inventory.getWarranty());
        inventory1.setAgreement(inventory.getAgreement());
        inventory1.setAttachment(inventory.getAttachment());
        inventory1.setAssigned(inventory.isAssigned());
        inventory1.setAdditionalDetails(inventory.getAdditionalDetails());
        inventory1.setLastUpdatedDate(inventory.getLastUpdatedDate());
        inventory1.setExpectedReturnDate(inventory.getExpectedReturnDate());
        inventory1.setDeviceType(inventory.getDeviceType());
        return inventoryRepository.save(inventory1);
    }

    @Override
    public List<Inventory> fetchAllInventory() {
        return inventoryRepository.findAll();
    }

    @Override
    public Inventory updateInventory(Inventory inventory, long id) {
        Inventory existingInventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Inventory not found with id: " + id));

        Inventory existingSerialNo = inventoryRepository.findBySerialNo(inventory.getSerialNo());
        Inventory existingAssetTagId = inventoryRepository.findByAssetTagId(inventory.getAssetTagId());

        if (existingSerialNo != null && existingSerialNo.getId() != id) {
            throw new IllegalArgumentException("serial number already exist");
        }

        if (existingAssetTagId != null && existingAssetTagId.getId() != id) {
            throw new IllegalArgumentException("asset tag id already exist");
        }

        existingInventory.setEmployeeName(inventory.getEmployeeName());
        existingInventory.setEmployeeId(inventory.getEmployeeId());
        existingInventory.setMake(inventory.getMake());
        existingInventory.setModel(inventory.getModel());
        existingInventory.setProcessor(inventory.getProcessor());
        existingInventory.setRamSize(inventory.getRamSize());
        existingInventory.setStorageSize(inventory.getStorageSize());
        existingInventory.setSerialNo(inventory.getSerialNo());
        existingInventory.setAssetTagId(inventory.getAssetTagId());
        existingInventory.setWarranty(inventory.getWarranty());
        existingInventory.setAgreement(inventory.getAgreement());
        existingInventory.setAttachment(existingInventory.getAttachment());
        existingInventory.setAssigned(inventory.isAssigned());
        existingInventory.setAdditionalDetails(inventory.getAdditionalDetails());
        existingInventory.setLastUpdatedDate(inventory.getLastUpdatedDate());
        existingInventory.setExpectedReturnDate(inventory.getExpectedReturnDate());
        existingInventory.setDeviceType(inventory.getDeviceType());
        return inventoryRepository.save(existingInventory);
    }

    @Override
    public Inventory updateInventoryWithImage(InventoryDto inventoryDto, long id) throws IOException {
        Inventory existingInventory = inventoryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Inventory not found with id: " + id));

        Inventory existingSerialNo = inventoryRepository.findBySerialNo(inventoryDto.getSerialNo());
        Inventory existingAssetTagId = inventoryRepository.findByAssetTagId(inventoryDto.getAssetTagId());

        if (existingSerialNo != null && existingSerialNo.getId() != id) {
            throw new IllegalArgumentException("serial number already exist");
        }

        if (existingAssetTagId != null && existingAssetTagId.getId() != id) {
            throw new IllegalArgumentException("asset tag id already exist");
        }


//        if (existingInventory.getAttachment() != null && !existingInventory.getAttachment().isEmpty()) {
//            BlobClient existingBlobClient = blobServiceClient.getBlobContainerClient(blobContainerName).getBlobClient(existingInventory.getAttachment());
//            existingBlobClient.delete();
//        }

        String attachment = null;
        if (inventoryDto.getAttachment() != null && !inventoryDto.getAttachment().isEmpty()) {
            BlobClient blobClient = blobServiceClient.getBlobContainerClient(blobContainerName).getBlobClient(inventoryDto.getAttachment().getOriginalFilename());
            blobClient.upload(inventoryDto.getAttachment().getInputStream(), inventoryDto.getAttachment().getSize(), true);
            attachment = blobClient.getBlobUrl();
        }

        existingInventory.setEmployeeName(inventoryDto.getEmployeeName());
        existingInventory.setEmployeeId(inventoryDto.getEmployeeId());
        existingInventory.setMake(inventoryDto.getMake());
        existingInventory.setModel(inventoryDto.getModel());
        existingInventory.setProcessor(inventoryDto.getProcessor());
        existingInventory.setRamSize(inventoryDto.getRamSize());
        existingInventory.setStorageSize(inventoryDto.getStorageSize());
        existingInventory.setSerialNo(inventoryDto.getSerialNo());
        existingInventory.setAssetTagId(inventoryDto.getAssetTagId());
        existingInventory.setWarranty(inventoryDto.getWarranty());
        existingInventory.setAgreement(inventoryDto.getAgreement());
        existingInventory.setAttachment(attachment);
        existingInventory.setAssigned(inventoryDto.isAssigned());
        existingInventory.setAdditionalDetails(inventoryDto.getAdditionalDetails());
        existingInventory.setLastUpdatedDate(inventoryDto.getLastUpdatedDate());
        existingInventory.setExpectedReturnDate(inventoryDto.getExpectedReturnDate());
        existingInventory.setDeviceType(inventoryDto.getDeviceType());
        return inventoryRepository.save(existingInventory);
    }
}

