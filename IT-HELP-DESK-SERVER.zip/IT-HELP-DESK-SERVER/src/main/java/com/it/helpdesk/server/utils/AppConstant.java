package com.it.helpdesk.server.utils;

public class AppConstant {

    public final static String ROLE = "roles";
    public final static String TICKET_WRITE = "ticket.write";
    public final static String TICKET_HR = "ticket.hr";
    public final static String AUDIENCE = "aud";
    public final static String USERNAME = "name";
    public final static String EMAIL = "preferred_username";
    public final static String USER_NOT_AUTHENTICATED = "User not authenticated";

}
