package com.it.helpdesk.server.repository;

import com.it.helpdesk.server.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {

    boolean existsByAssetTagId(String assetTagId);

    boolean existsBySerialNo(String serialNo);

    Inventory findBySerialNo(String serialNo);

    Inventory findByAssetTagId(String assetTagId);
}
