package com.it.helpdesk.server.utils;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
public class SkillsResponse {

    private List<String> skills;
}
