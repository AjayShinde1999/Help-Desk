package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.EmployeeData;
import com.it.helpdesk.server.payload.EmployeeDataDto;
import com.it.helpdesk.server.utils.ApiResponse;

import java.util.List;

public interface EmployeeDataService {

    EmployeeData saveOneEmployee(EmployeeData employeeData);

    List<EmployeeData> searchEmployeeDataForAdmin(String q) throws InterruptedException;

    List<Object> searchEmployeeDataForUser(String email,String q);

    ApiResponse deleteOneEmployeeDataByEmail(long id);

    EmployeeData updateEmployeeData(EmployeeData employeeData, long id);

    EmployeeData getEmployeeDataByEmail(String email);

    EmployeeData updateEmployeeDataOnlySkills(EmployeeData employeeData, long id);

    List<EmployeeData> saveListOfEmployees(List<EmployeeData> employeeData);

    List<EmployeeData> getAllEmployees();
}
