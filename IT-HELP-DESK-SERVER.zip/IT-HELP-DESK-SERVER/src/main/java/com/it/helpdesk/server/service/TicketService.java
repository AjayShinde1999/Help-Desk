package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.TicketDto;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.List;

public interface TicketService {
    Ticket createTicketWithImage(String username, String email, TicketDto ticketDto,List<String> roles) throws IOException, MessagingException;

    List<Ticket> fetchTicketByEmail(String email);

    List<Ticket> fetchAllTickets();

    Ticket updateTicketById(Ticket ticket, long id) throws MessagingException;

    Ticket saveOneTicketWithoutImage(String username, String email, Ticket ticket,List<String> roles) throws IOException, MessagingException;


    List<Ticket> fetchTicketByHrIssue(String email);

    List<Ticket> fetchTicketsByCategoryOtherThanHR(String email1);
}
