package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.payload.DropdownValues;
import com.it.helpdesk.server.payload.TicketDto;
import com.it.helpdesk.server.security.TicketAuthentication;
import com.it.helpdesk.server.service.ExcelService;
import com.it.helpdesk.server.utils.ApiResponse;
import com.it.helpdesk.server.utils.ExcelResponse;
import com.it.helpdesk.server.utils.RefreshResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {

    @Autowired
    private TicketAuthentication ticketAuthentication;

    @Autowired
    private ExcelService excelService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Ticket createTicketWithImage(@AuthenticationPrincipal Jwt jwt, TicketDto ticketDto) throws IOException, MessagingException {
        return ticketAuthentication.authenticateUserForTicketWithImage(jwt, ticketDto);
    }

    @PostMapping("no-image")
    @ResponseStatus(HttpStatus.CREATED)
    public Ticket createTicketWithoutImage(@AuthenticationPrincipal Jwt jwt, Ticket ticket) throws MessagingException, IOException {
        return ticketAuthentication.authenticateUserForTicketWithoutImage(jwt, ticket);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Ticket> fetchAllTickets(@AuthenticationPrincipal Jwt jwt) {
        return ticketAuthentication.authenticateUserForFetchAllTickets(jwt);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Ticket updateTicket(@AuthenticationPrincipal Jwt jwt, @RequestBody Ticket ticket, @PathVariable long id) throws IOException, MessagingException {
        return ticketAuthentication.authenticateUserForUpdateTicket(jwt, ticket, id);
    }

    @GetMapping("/dropdownvalues")
    public ResponseEntity<DropdownValues> fetchDropdownValues(@AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(ticketAuthentication.authenticateUserForFetchDropdownValues(jwt));
    }

    @GetMapping("/token-status")
    @ResponseStatus(HttpStatus.OK)
    public RefreshResponse refreshToken() {
        RefreshResponse response = new RefreshResponse();
        response.setStatus("OK");
        return response;
    }

    @GetMapping("/download-archive")
    @ResponseStatus(HttpStatus.OK)
    public ExcelResponse downloadArchive(@AuthenticationPrincipal Jwt jwt) throws IOException {
        return excelService.exportTicketsToExcel(jwt);
    }
}