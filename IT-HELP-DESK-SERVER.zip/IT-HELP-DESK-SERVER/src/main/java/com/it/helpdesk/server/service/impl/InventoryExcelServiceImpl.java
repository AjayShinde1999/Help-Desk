package com.it.helpdesk.server.service.impl;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.models.BlobItem;
import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.repository.InventoryRepository;
import com.it.helpdesk.server.service.InventoryExcelService;
import com.it.helpdesk.server.utils.ExcelResponse;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class InventoryExcelServiceImpl implements InventoryExcelService {

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private BlobServiceClient blobServiceClient;

    @Value("${azure.blob.containerName}")
    private String blobContainerName;


    @Override
    public ExcelResponse exportInventoryToExcel() throws IOException {
        List<Inventory> inventories = inventoryRepository.findAll();
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet();

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("id");
            headerRow.createCell(1).setCellValue("employee_name");
            headerRow.createCell(2).setCellValue("employee_id");
            headerRow.createCell(3).setCellValue("make");
            headerRow.createCell(4).setCellValue("model");
            headerRow.createCell(5).setCellValue("processor");
            headerRow.createCell(6).setCellValue("ram_size");
            headerRow.createCell(7).setCellValue("storage_size");
            headerRow.createCell(8).setCellValue("serial_no");
            headerRow.createCell(9).setCellValue("asset_tag_id");
            headerRow.createCell(10).setCellValue("warranty");
            headerRow.createCell(11).setCellValue("agreement");
            headerRow.createCell(12).setCellValue("attachment");
            headerRow.createCell(13).setCellValue("assigned");
            headerRow.createCell(14).setCellValue("additional_details");
            headerRow.createCell(15).setCellValue("last_updated_date");
            headerRow.createCell(16).setCellValue("expected_return_date");
            headerRow.createCell(17).setCellValue("device_type");

            int rowNum = 1;
            for (Inventory inventory : inventories) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(inventory.getId());
                row.createCell(1).setCellValue(inventory.getEmployeeName());
                row.createCell(2).setCellValue(inventory.getEmployeeId());
                row.createCell(3).setCellValue(inventory.getMake());
                row.createCell(4).setCellValue(inventory.getModel());
                row.createCell(5).setCellValue(inventory.getProcessor());
                row.createCell(6).setCellValue(inventory.getRamSize());
                row.createCell(7).setCellValue(inventory.getStorageSize());
                row.createCell(8).setCellValue(inventory.getSerialNo());
                row.createCell(9).setCellValue(inventory.getAssetTagId());
                row.createCell(10).setCellValue(inventory.getWarranty());
                row.createCell(11).setCellValue(inventory.getAgreement());
                row.createCell(12).setCellValue(inventory.getAttachment());
                row.createCell(13).setCellValue(inventory.isAssigned());
                row.createCell(14).setCellValue(inventory.getAdditionalDetails());
                row.createCell(15).setCellValue(inventory.getLastUpdatedDate());
                row.createCell(16).setCellValue(inventory.getExpectedReturnDate());
                row.createCell(17).setCellValue(inventory.getDeviceType());
            }

            File tempFile = File.createTempFile("inventory_data_sheet", ".xlsx");
            try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                workbook.write(outputStream);
            }

            BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(blobContainerName);

            for (BlobItem blobItem : containerClient.listBlobs()) {
                String blobName = blobItem.getName();
                if (blobName.contains("inventory_data_sheet") && blobName.contains(".xlsx")) {
                    containerClient.getBlobClient(blobName).delete();
                }
            }
            BlobClient blobClient = containerClient.getBlobClient(tempFile.getName());
            blobClient.uploadFromFile(tempFile.getAbsolutePath());
            String blobUrl = blobClient.getBlobUrl();

            ExcelResponse response = new ExcelResponse();
            response.setStatus("Success");
            response.setFileUrl(blobUrl);
            return response;
        }
    }
}

