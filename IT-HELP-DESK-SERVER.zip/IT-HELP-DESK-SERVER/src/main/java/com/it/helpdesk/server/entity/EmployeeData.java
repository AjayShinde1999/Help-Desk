package com.it.helpdesk.server.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "employee_data")
public class EmployeeData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String employeeId;
    private String name;
    private String mobileNumber;
    private String email;
    private String project;
    private String reportingManager;
    private String designation;
    private String experience;
    @Column(length = 1000)
    private String skills;
}
