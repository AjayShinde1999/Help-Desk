package com.it.helpdesk.server.payload;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class InventoryDto {

    private Long id;
    private String employeeName;
    private String employeeId;
    private String make;
    private String model;
    private String processor;
    private String ramSize;
    private String storageSize;
    private String serialNo;
    private String assetTagId;
    private String warranty;
    private String agreement;
    private MultipartFile attachment;
    private boolean assigned;
    private String additionalDetails;
    private String lastUpdatedDate;
    private String expectedReturnDate;
    private String deviceType;
}
