package com.it.helpdesk.server.service;

import com.it.helpdesk.server.entity.Skills;
import com.it.helpdesk.server.utils.SkillsResponse;

import java.util.List;

public interface SkillsService {

    List<Skills>  saveSkills(List<Skills> skills);

    SkillsResponse searchSkills();
}
