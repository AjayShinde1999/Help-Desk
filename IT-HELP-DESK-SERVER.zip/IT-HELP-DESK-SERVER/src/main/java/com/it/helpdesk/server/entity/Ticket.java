package com.it.helpdesk.server.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "tickets")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "ticket_no")
    private String ticketNo;
    private String username;
    private String email;
    private String subject;
    private String date;
    private String priority;
    private String category;
    private String status;
    @Column(length = 500)
    private String description;
    private String imageUrl;
    @Column(length = 500)
    private String comments;
    private String ticketCloseDate;
    private String modifiedBy;
    private int unreadMsgCount;
    private String ticketOwnerRole;
}
