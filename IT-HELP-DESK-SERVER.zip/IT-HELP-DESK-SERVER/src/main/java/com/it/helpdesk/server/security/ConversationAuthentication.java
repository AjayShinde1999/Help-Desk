package com.it.helpdesk.server.security;

import com.it.helpdesk.server.entity.Conversation;
import com.it.helpdesk.server.service.ConversationService;
import com.it.helpdesk.server.utils.AppConstant;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

import java.nio.file.AccessDeniedException;
import java.util.List;

@Component
public class ConversationAuthentication {

    private ConversationService conversationService;

    public ConversationAuthentication(ConversationService conversationService) {
        this.conversationService = conversationService;
    }

    @Value("${azure.client-id}")
    private String CLIENT_ID;

    public Conversation authenticateUsersForSendConversation(Jwt jwt, Conversation conversation, long ticketId) throws AccessDeniedException {
        Object audience = jwt.getClaim(AppConstant.AUDIENCE);
        if (audience instanceof List && ((List<?>) audience).contains(CLIENT_ID)) {
            return conversationService.saveConversation(jwt, conversation, ticketId);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }

    public List<Conversation> authenticateUsersForFetchAllConversation(Jwt jwt, long ticketId) throws AccessDeniedException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        Object audience = jwt.getClaim(AppConstant.AUDIENCE);
        if (roles != null && (roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR))) {
            return conversationService.fetchUsersMessagesForAdmin(ticketId,roles);
        } else if (roles == null && audience instanceof List && ((List<?>) audience).contains(CLIENT_ID)) {
            return conversationService.fetchAdminMessagesForUser(ticketId);
        } else {
            throw new AccessDeniedException(AppConstant.USER_NOT_AUTHENTICATED);
        }
    }
}

