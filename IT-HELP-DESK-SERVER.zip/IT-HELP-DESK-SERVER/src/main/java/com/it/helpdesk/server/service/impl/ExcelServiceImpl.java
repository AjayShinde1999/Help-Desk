package com.it.helpdesk.server.service.impl;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.models.BlobItem;
import com.it.helpdesk.server.entity.Inventory;
import com.it.helpdesk.server.entity.Ticket;
import com.it.helpdesk.server.repository.InventoryRepository;
import com.it.helpdesk.server.repository.TicketRepository;
import com.it.helpdesk.server.service.ExcelService;
import com.it.helpdesk.server.utils.AppConstant;
import com.it.helpdesk.server.utils.ExcelResponse;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExcelServiceImpl implements ExcelService {

    @Value("${azure.blob.containerName}")
    private String blobContainerName;

    @Autowired
    private BlobServiceClient blobServiceClient;

    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private InventoryRepository inventoryRepository;

    public ExcelResponse exportTicketsToExcel(Jwt jwt) throws IOException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        List<Ticket> tickets = ticketRepository.findAll();
        ExcelResponse response = null;
        if (roles.contains(AppConstant.TICKET_WRITE)) {
            response = exportTickets(tickets);
        } else if (roles.contains(AppConstant.TICKET_HR)) {
            List<Ticket> ticketList = tickets.stream().filter(ticket -> ticket.getCategory().equals("hr related issue")).collect(Collectors.toList());
            response = exportTickets(ticketList);
        }
        return response;
    }

    public ExcelResponse exportTickets(List<Ticket> tickets) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet();

            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("ID");
            headerRow.createCell(1).setCellValue("Ticket No");
            headerRow.createCell(2).setCellValue("Username");
            headerRow.createCell(3).setCellValue("Email");
            headerRow.createCell(4).setCellValue("Subject");
            headerRow.createCell(5).setCellValue("Date");
            headerRow.createCell(6).setCellValue("Priority");
            headerRow.createCell(7).setCellValue("Category");
            headerRow.createCell(8).setCellValue("Status");
            headerRow.createCell(9).setCellValue("Description");
            headerRow.createCell(10).setCellValue("Image URL");
            headerRow.createCell(11).setCellValue("Ticket Close Date");
            headerRow.createCell(12).setCellValue("Modified By");
            headerRow.createCell(13).setCellValue("Comments");

            int rowNum = 1;
            for (Ticket ticket : tickets) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(ticket.getId());
                row.createCell(1).setCellValue(ticket.getTicketNo());
                row.createCell(2).setCellValue(ticket.getUsername());
                row.createCell(3).setCellValue(ticket.getEmail());
                row.createCell(4).setCellValue(ticket.getSubject());
                row.createCell(5).setCellValue(ticket.getDate());
                row.createCell(6).setCellValue(ticket.getPriority());
                row.createCell(7).setCellValue(ticket.getCategory());
                row.createCell(8).setCellValue(ticket.getStatus());
                row.createCell(9).setCellValue(ticket.getDescription());
                row.createCell(10).setCellValue(ticket.getImageUrl());
                row.createCell(11).setCellValue(ticket.getTicketCloseDate());
                row.createCell(12).setCellValue(ticket.getModifiedBy());
                row.createCell(13).setCellValue(ticket.getComments());
            }


            File tempFile = File.createTempFile("archive_data_sheet", ".xlsx");
            try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
                workbook.write(outputStream);
            }

            BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(blobContainerName);

            for (BlobItem blobItem : containerClient.listBlobs()) {
                String blobName = blobItem.getName();
                if (blobName.contains("archive_data_sheet") && blobName.contains(".xlsx")) {
                    containerClient.getBlobClient(blobName).delete();
                }
            }
            BlobClient blobClient = containerClient.getBlobClient(tempFile.getName());
            blobClient.uploadFromFile(tempFile.getAbsolutePath());
            String blobUrl = blobClient.getBlobUrl();

            ExcelResponse response = new ExcelResponse();
            response.setStatus("Success");
            response.setFileUrl(blobUrl);
            return response;
        }
    }
}



