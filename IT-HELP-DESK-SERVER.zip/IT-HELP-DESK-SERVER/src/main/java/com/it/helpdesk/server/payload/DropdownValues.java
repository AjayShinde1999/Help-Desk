package com.it.helpdesk.server.payload;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class DropdownValues {

    private List<String> priority;
    private List<String> category;

}
