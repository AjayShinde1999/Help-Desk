package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.EmployeeData;
import com.it.helpdesk.server.security.EmployeeDataAuthentication;
import com.it.helpdesk.server.service.EmployeeDataExcelService;
import com.it.helpdesk.server.service.EmployeeDataService;
import com.it.helpdesk.server.utils.ApiResponse;
import com.it.helpdesk.server.utils.AppConstant;
import com.it.helpdesk.server.utils.ExcelResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.util.List;

@RestController
@RequestMapping("/api/employee-data")
public class EmployeeDataController {

    private EmployeeDataAuthentication employeeDataAuthentication;

    private EmployeeDataService employeeDataService;

    private EmployeeDataExcelService employeeDataExcelService;

    public EmployeeDataController(EmployeeDataAuthentication employeeDataAuthentication, EmployeeDataService employeeDataService, EmployeeDataExcelService employeeDataExcelService) {
        this.employeeDataAuthentication = employeeDataAuthentication;
        this.employeeDataService = employeeDataService;
        this.employeeDataExcelService = employeeDataExcelService;
    }

    @PostMapping("/employee")
    @ResponseStatus(HttpStatus.CREATED)
    public EmployeeData saveEmployeeData(@AuthenticationPrincipal Jwt jwt, @RequestBody EmployeeData employeeData) throws AccessDeniedException {
        return employeeDataAuthentication.authenticateAdminToSaveEmployeeData(jwt, employeeData);
    }

    @GetMapping("/employee")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeData fetchEmployeeDataByEmail(@AuthenticationPrincipal Jwt jwt) throws AccessDeniedException {
        return employeeDataAuthentication.authenticateAdminOrUserToFetchEmployeeData(jwt);
    }

    @PutMapping("/employee/{id}")
    @ResponseStatus(HttpStatus.OK)
    public EmployeeData updateEmployeeData(@AuthenticationPrincipal Jwt jwt, @RequestBody EmployeeData employeeData, @PathVariable long id) throws AccessDeniedException {
        return employeeDataAuthentication.authenticateAdminOrUserToUpdateEmployeeData(jwt, employeeData, id);
    }

    @DeleteMapping("/employee/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ApiResponse deleteEmployeeDataByEmail(@AuthenticationPrincipal Jwt jwt, @PathVariable long id) throws AccessDeniedException {
        return employeeDataAuthentication.authenticateAdminToDeleteEmployeeData(jwt, id);
    }

    @GetMapping("/search-result")
    @ResponseStatus(HttpStatus.OK)
    public Object searchEmployees(@AuthenticationPrincipal Jwt jwt, @RequestParam("q") String q) throws AccessDeniedException, InterruptedException {
        return employeeDataAuthentication.authenticateAdminOrUserToSearchEmployeeData(jwt, q);
    }

    @PostMapping("/all")
    @ResponseStatus(HttpStatus.CREATED)
    public List<EmployeeData> saveListOfEmployeeData(@RequestBody List<EmployeeData> employeeData) {
        return employeeDataService.saveListOfEmployees(employeeData);
    }

    @GetMapping("/all")
    @ResponseStatus(HttpStatus.CREATED)
    public List<EmployeeData> getAllEmployeeData() {
        return employeeDataService.getAllEmployees();
    }

    @GetMapping("/download-employees-list")
    @ResponseStatus(HttpStatus.OK)
    public ExcelResponse downloadArchive(@AuthenticationPrincipal Jwt jwt) throws IOException {
        List<String> roles = jwt.getClaim(AppConstant.ROLE);
        if (roles != null || roles.contains(AppConstant.TICKET_WRITE) || roles.contains(AppConstant.TICKET_HR)) {
            return employeeDataExcelService.exportEmployeeDataToExcel(roles);
        } else {
            throw new AccessDeniedException("Unauthorized");
        }
    }
}
