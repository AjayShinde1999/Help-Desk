package com.it.helpdesk.server.service.impl;

import com.it.helpdesk.server.entity.Skills;
import com.it.helpdesk.server.repository.SkillsRepository;
import com.it.helpdesk.server.service.SkillsService;
import com.it.helpdesk.server.utils.SkillsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class SkillsServiceImpl implements SkillsService {

    @Autowired
    private SkillsRepository skillsRepository;

    @Override
    public List<Skills> saveSkills(List<Skills> skills) {
        return skillsRepository.saveAll(skills);
    }

    @Override
    public SkillsResponse searchSkills() {
        List<Skills> listOfAllSkills = skillsRepository.findAll();
        List<String> skills = new ArrayList<>();
        for (Skills skill : listOfAllSkills) {
            String name = skill.getName();
            skills.add(name);
        }
        SkillsResponse response = new SkillsResponse();
        response.setSkills(skills);
        return response;
    }
}
