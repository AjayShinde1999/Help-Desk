package com.it.helpdesk.server.controller;

import com.it.helpdesk.server.entity.Skills;
import com.it.helpdesk.server.service.SkillsService;
import com.it.helpdesk.server.utils.SkillsResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/skills")
public class SkillsController {

    @Autowired
    private SkillsService skillsService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public List<Skills> saveOneSkills(@RequestBody List<Skills> skills) {
        return skillsService.saveSkills(skills);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public SkillsResponse searchSkills() {
        return skillsService.searchSkills();
    }

}
